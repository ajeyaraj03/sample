package com.ekart.facp.unitization.apis;

import java.util.List;

/**
 * Created by anurag.gupta on 01/07/16.
 */
public class RootContainerCreationRequest {

    private String createdByDocumentId;
    private String createdByDocumentType;
    private String idempotenceKey;
    private String requestedBy;
    private List<RootContainerCreationRequestAttributes> itemRequests;

    public String getCreatedByDocumentId() {
        return createdByDocumentId;
    }

    public void setCreatedByDocumentId(String createdByDocumentId) {
        this.createdByDocumentId = createdByDocumentId;
    }

    public String getCreatedByDocumentType() {
        return createdByDocumentType;
    }

    public void setCreatedByDocumentType(String createdByDocumentType) {
        this.createdByDocumentType = createdByDocumentType;
    }

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }

    public List<RootContainerCreationRequestAttributes> getItemRequests() {
        return itemRequests;
    }

    public void setItemRequests(List<RootContainerCreationRequestAttributes> itemRequests) {
        this.itemRequests = itemRequests;
    }

    @Override
    public String toString() {
        return "RootContainerCreationRequest{"
                + "createdByDocumentId='" + createdByDocumentId + '\''
                + ", createdByDocumentType='" + createdByDocumentType + '\''
                + ", idempotenceKey='" + idempotenceKey + '\''
                + ", requestedBy='" + requestedBy + '\''
                + ", itemRequests=" + itemRequests
                + '}';
    }
}
