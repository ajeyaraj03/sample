package com.ekart.facp.unitization.apis;

import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.dtos.Specification;
import com.ekart.facp.unitization.apis.dtos.SpecificationCreationRequest;
import com.ekart.facp.unitization.apis.dtos.SpecificationUpdateRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

/**
 * @author vijay.daniel
 */
public final class TestUtils {

    private static final boolean REUSABLE = true;
    private static final String TYPE = "type";
    private static final String UPDATED_BY = "self";
    private static final String CREATED_BY = "self";
    private static final Map<String, String> ATTRIBUTES = new HashMap();
    private static final boolean ACTIVE = true;

    public static void assertBadRequest(ResponseEntity<ErrorMessage> responseEntity) {

        assertThat(responseEntity.getStatusCode().value(), is(HttpStatus.BAD_REQUEST.value()));
    }

    public static <T> void assertResponse(ResponseEntity<T> actualResponse, HttpStatus expectedStatus, T expectedBody) {

        assertThat(actualResponse.getStatusCode(), is(expectedStatus));
        assertThat(actualResponse.getBody(), is(expectedBody));
    }

    public static SpecificationCreationRequest newSpecificationCreateRequest(String type) {
        SpecificationCreationRequest creationRequest = new SpecificationCreationRequest();
        creationRequest.setReusable(REUSABLE);
        creationRequest.setActive(ACTIVE);
        creationRequest.setCreatedBy(CREATED_BY);
        creationRequest.setAttributes(ATTRIBUTES);
        creationRequest.setType(type);
        return creationRequest;
    }

    public static Specification getSpecificationResponse(String specificationId, String tenantId, String type) {
        Specification response = new Specification();
        response.setId(specificationId);
        response.setReusable(REUSABLE);
        response.setCreatedBy(CREATED_BY);
        response.setUpdatedBy(UPDATED_BY);
        response.setTenant(tenantId);
        response.setType(type);
        response.setActive(ACTIVE);
        response.setAttributes(ATTRIBUTES);
        return response;
    }

    public static SpecificationUpdateRequest specificationUpdateRequest() {
        SpecificationUpdateRequest specificationUpdateRequest = new SpecificationUpdateRequest();
        specificationUpdateRequest.setReusable(REUSABLE);
        specificationUpdateRequest.setActive(ACTIVE);
        specificationUpdateRequest.setUpdatedBy(UPDATED_BY);
        specificationUpdateRequest.setAttributes(ATTRIBUTES);
        return specificationUpdateRequest;
    }

    public static void compareSpecificationResponse(Specification expected, Specification actual) {
        assertThat(expected.getId(), is(actual.getId()));
        assertThat(expected.getAttributes(), is(actual.getAttributes()));
        assertThat(expected.getCreatedBy(), is(actual.getCreatedBy()));
        assertThat(expected.getUpdatedBy(), is(actual.getUpdatedBy()));
        assertThat(expected.getTenant(), is(actual.getTenant()));
        assertThat(expected.getType(), is(actual.getType()));
    }

}
