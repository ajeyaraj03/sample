package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.BaseIntegrationTest;
import com.ekart.facp.unitization.apis.dtos.*;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.MAX_LABELS_TO_BE_ADDED;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;

import com.ekart.facp.unitization.service.dtos.clients.ims.response.GetItemResponse;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;


import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import static com.ekart.facp.unitization.apis.TestUtils.*;
import static com.ekart.facp.unitization.apis.UnitizationTestUtils.*;
import static com.ekart.facp.unitization.common.ErrorCode.*;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang.RandomStringUtils.randomAlphanumeric;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by avinash.r on 13/07/16.
 */
public class UnitizationUpdateIntegrationTest extends BaseIntegrationTest {

    private final String clientId = randomAlphanumeric(20);
    private final String rootContainerId = randomAlphanumeric(20);
    private final String rootContainerItemType = randomAlphanumeric(20);
    private final String containerType = randomAlphanumeric(20);
    private final String transientContainerType = randomAlphanumeric(20);
    private final String itemType = randomAlphanumeric(20);
    private final String randomType = randomAlphanumeric(20);
    private final String itemLabelType = randomAlphanumeric(20);
    private final String containerLabelType = randomAlphanumeric(20);
    private final String transientContainerLabelType = randomAlphanumeric(20);
    private static final String CONTAINER_LABEL = randomAlphanumeric(20);
    private static final String BULK = randomAlphanumeric(20);
    private String containerId;
    private UpdateRequest updateRequest;
    private final ObjectMapper objectMapper = objectMapper();

    @Before
    public void setUp() throws IOException {

        // Items with labels S1,S2,S3 with same random type have weights
        createSpecifications();
        createContainersAndTypes();
        updateRequest = createUpdateRequest(containerType, "containerLabel", rootContainerId, "flow",
                containerLabelType, "stateMachine", "transition");
    }

    @Test
    public void shouldThrow400IfIdempotenceKeyIsNotPresentInRequest() {

        updateRequest.setIdempotenceKey(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.idempotenceKey: idempotenceKey cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfContainerLabelIsNotPresentInRequest() {

        updateRequest.getUpdateRequestItems().get(0).setLabel(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.updateRequestItems[0].label: label can not be null.]");
    }

    @Test
    public void shouldThrow400IfContainerLabelTypeIsNotPresentInRequest() {

        updateRequest.getUpdateRequestItems().get(0).setLabelType(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.updateRequestItems[0].labelType: labelType cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfContainerTypeIsNotPresentInRequest() {

        updateRequest.getUpdateRequestItems().get(0).setType(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.updateRequestItems[0].type: containerType can not be null.]");
    }

    @Test
    public void shouldThrow400IfRequestedByIsNotPresentInRequest() {

        updateRequest.setRequestedBy(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.requestedBy: requestedBy can not be null.]");
    }

    @Test
    public void shouldThrow400IfFacilityIdIsNotPresentInRequest() {

        updateRequest.setFacilityId(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.facilityId: facilityId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfAppIdIsNotPresentInRequest() {

        updateRequest.setAppId(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.appId: appId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfTransitionNameIsNotPresentInRequest() {

        updateRequest.getUpdateRequestItems().get(0).setTransitionName(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.updateRequestItems[0].transitionName: transitionName can not be null.]");
    }

    @Test
    public void shouldThrow400IfStateMachineIdIsNotPresentInRequest() {

        updateRequest.getUpdateRequestItems().get(0).setStateMachineId(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
              "[NotNull.updateRequest.updateRequestItems[0].stateMachineId: stateMachineId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfFlowContextIsNotPresentInRequest() {

        updateRequest.setFlowContext(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.flowContext: flowContext cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfCreatedByEntityTypeIsNotPresentInRequest() {

        updateRequest.setCreatedByEntityType(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.createdByEntityType: createdByEntityType cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfCreatedByEntityIdIsNotPresentInRequest() {

        updateRequest.setCreatedByEntityId(null);
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[NotNull.updateRequest.createdByEntityId: createdByEntityId cannot be null or empty.]");
    }

    @Test
    public void shouldThrow400IfUpdateRequestHasMoreRecordsThanConfigured() {

        updateRequest = createUpdateRequest(itemType, "S1", rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().add(updateRequest.getUpdateRequestItems().get(0));
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[Size.updateRequest.updateRequestItems: Please provide only one item to update]");
    }

    @Test
    public void shouldThrow400IfUpdateRequestHasMoreLabelsToBeAddedThanConfigured() {

        updateRequest = createUpdateRequest(itemType, "S1", rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().get(0).setLabelsToBeAdded(Lists.newArrayList());
        for (int i = 0; i < MAX_LABELS_TO_BE_ADDED + 1; ++i) {
            updateRequest.getUpdateRequestItems().get(0).getLabelsToBeAdded()
                    .add(new Label(randomAlphabetic(10), randomAlphabetic(10)));
        }
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), VALIDATION_ERROR.name(),
                "[Size.updateRequest.updateRequestItems[0].labelsToBeAdded: maximum allowed labels are 5]");
    }

    //IMS Validation
    @Test
    public void shouldThrow400IfContainerIsNotPresentInIms() {

        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class),
                LABEL_NOT_FOUND_EXCEPTION.name(),
                "Item with label containerLabel and type " + containerLabelType + " not found");
    }

    //label service needs to be integrated

    //FSM Validation
    @Test
    public void shouldThrow400IfStateMachineForContainerIsNotPresentInFsm() {

        updateRequest = createUpdateRequest(containerType, CONTAINER_LABEL, rootContainerId, "3PL",
                containerLabelType, "stateMachine", "transition");
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class),
                INVALID_STATE_MACHINE_EXCEPTION.name(), "Invalid StateMachine: stateMachine");
    }

    @Test
    public void shouldThrow400IfTransitionForContainerIsNotPresentInFsm() {

        updateRequest = createUpdateRequest(containerType, CONTAINER_LABEL, rootContainerId, "3PL",
                containerLabelType, STATE_MACHINE, "sampleTransition");
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class),
                INVALID_TRANSITION_EXCEPTION.name(),
                "sampleTransition is not a valid transition.");
    }

    //weight validations for parent contianer while updating weight
    @Test
    public void shouldThrow400IfParentContainerIsNotRootContainerAndNotInOpenStateWhileUpdatingWeight() {

        updateRequest = createUpdateRequest(itemType, "S1", rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new Attribute(WEIGHT.name(), 100.0)));
        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class),
                WEIGHT_EXCEEDED_EXCEPTION.name(),
                "Maximum allowed weight for item " + containerId + " is 50.0 but total provided weight is 120.0");
    }

    @Test
    public void shouldThrow400IfParentContainerIsNotRootContainerAndCanNotHoldMuchWeightWhileUpdatingWeight()
            throws IOException {

        updateRequest = createUpdateRequest(itemType, "S2", rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new Attribute(WEIGHT.name(), 100.0)));

        String container = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(itemLabelType, "S2")).getBody()).get(0).getContainerId();

        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class),
                WEIGHT_EXCEEDED_EXCEPTION.name(),
                "Maximum allowed weight for item " + container + " is 50.0 but total provided weight is 110.0");
    }

    @Test
    public void shouldThrow400IfParentContainerDoesNotHaveCurrentWeightAttributeAndIsNonTransient() {

        createUnitizableInImsWithoutWeight(itemType, "S4");
        String newNonTransientContainerLabel = "newContainer";
        assertCreated(API.createContainer(clientId, createContainer(containerType, newNonTransientContainerLabel,
                containerLabelType, rootContainerId), SuccessResponse.class));

        assertOk(API.addToContainer(clientId, createAddRequest(newNonTransientContainerLabel, containerType,
                containerLabelType, rootContainerId, "3PL", STATE_MACHINE,
                createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4")), SuccessResponse.class));

        updateRequest = createUpdateRequest(itemType, "S4", rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new Attribute(WEIGHT.name(), new BigDecimal(30.0))));

        assertBadRequest(API.updateItem(clientId, updateRequest, ErrorMessage.class), UPDATE_EXCEPTION.name(),
                "Can not update weight, items in container do not have weight");
    }

    //updating weight of container
    @Test
    public void shouldUpdateWeightOfContainerIfParentContainerHasCurrentWeightAndIsNonTransient() throws IOException {

        updateRequest = createUpdateRequest(itemType, "S2", rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new Attribute(WEIGHT.name(), new BigDecimal(30.0))));

        assertOk(API.updateItem(clientId, updateRequest, SuccessResponse.class));

        Item updatedContainer = getItemsFromResponse(
                API.getItemFromImsByLabel(rootContainerId, new Label(itemLabelType, "S2")).getBody()).get(0);

        assertThat(new BigDecimal(updatedContainer.getAttributes().get(WEIGHT.name())
                .getValue().toString()), is(new BigDecimal(30.0)));

        assertThat(new BigDecimal(getItemsFromResponse(API.getItemFromImsById(rootContainerId,
                updatedContainer.getContainerId()).getBody()).get(0).getAttributes()
                .get(UNITIZATION_CURRENT_WEIGHT.name()).getValue().toString()), is(new BigDecimal("40.0")));
    }

    @Test
    public void shouldUpdateWeightOfContainerIfParentContainerIsTransient() throws IOException {

        createUnitizableInIms("S4", 10.0);
        assertOk(API.addToContainer(clientId, createAddRequest(BULK, transientContainerType,
                transientContainerLabelType, rootContainerId, "3PL", STATE_MACHINE,
                createUnitizableRequests(itemLabelType, STATE_MACHINE, "S4")), SuccessResponse.class));

        updateRequest = createUpdateRequest(itemType, "S4", rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().get(0).setAttributes(
                Lists.newArrayList(new Attribute(WEIGHT.name(), new BigDecimal(30.0))));

        assertOk(API.updateItem(clientId, updateRequest, SuccessResponse.class));

        Item updatedContainer = getItemsFromResponse(
                API.getItemFromImsByLabel(rootContainerId, new Label(itemLabelType, "S4")).getBody()).get(0);

        assertThat(new BigDecimal(updatedContainer.getAttributes().get(WEIGHT.name()).getValue().toString()),
                is(new BigDecimal(30.0)));

        assertThat(getItemsFromResponse(API.getItemFromImsById(rootContainerId,
                updatedContainer.getContainerId()).getBody()).get(0).getAttributes()
                .containsKey(UNITIZATION_CURRENT_WEIGHT.name()), is(false));
    }

    //Adding labels to container
    @Test
    public void shouldAddNewLabelsToContainer() throws IOException {

        updateRequest = createUpdateRequest(containerType, CONTAINER_LABEL, rootContainerId, "3PL",
                containerLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().get(0).setLabelsToBeAdded(
                Lists.newArrayList(new Label(randomType, "R1")));

        assertOk(API.updateItem(clientId, updateRequest, SuccessResponse.class));
        assertReflectionEquals(getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                        new Label(randomType, "R1")).getBody()),
                getItemsFromResponse((API.getItemFromImsByLabel(rootContainerId,
                        new Label(containerLabelType, CONTAINER_LABEL)).getBody())));
    }

    @Test
    public void shouldUpdateExistingLabelsInContainer() throws IOException {

        updateRequest = createUpdateRequest(containerType, CONTAINER_LABEL, rootContainerId, "3PL",
                containerLabelType, STATE_MACHINE, "update");
        updateRequest.getUpdateRequestItems().get(0).setLabelsToBeAdded(
                Lists.newArrayList(new Label(containerLabelType, "R1")));

        Item container = getItemsFromResponse((API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody())).get(0);

        assertOk(API.updateItem(clientId, updateRequest, SuccessResponse.class));

        assertThat(getItemsFromResponse((API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody())).size(), is(0));

        assertThat(getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, "R1")).getBody()).get(0).getId(), is(container.getId()));
    }

    // update status
    @Test
    public void shouldUpdateStatusOfContainerWhenTransitionIsOtherThanUpdate() throws IOException {

        updateRequest = createUpdateRequest(containerType, CONTAINER_LABEL, rootContainerId, "3PL",
                containerLabelType, STATE_MACHINE, "close");

        assertOk(API.updateItem(clientId, updateRequest, SuccessResponse.class));
        assertThat(getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                        new Label(containerLabelType, CONTAINER_LABEL))
                        .getBody()).get(0).getStatuses().get("3PL_MH_" + containerType).getValue().toString(),
                is("CLOSE"));
    }

    private void createSpecifications() {

        SpecificationCreationRequest request = newSpecificationCreateRequest(containerType);
        request.setAttributes(ImmutableMap.of(MAX_WEIGHT.name(), "50.0",
                MAX_NO_OF_ITEMS.name(), "3"));
        API.createSpecification(clientId, request);
        request = newSpecificationCreateRequest(transientContainerType);
        API.createSpecification(clientId, request);
        request = newSpecificationCreateRequest(itemType);
        API.createSpecification(clientId, request);
    }

    private void createContainersAndTypes() throws IOException {

        API.createItemType(itemType);
        API.createItemType(randomType);
        API.createRootContainerItemType(containerType, Lists.newArrayList(itemType));
        API.createRootContainerItemType(transientContainerType, Lists.newArrayList(itemType));
        API.createRootContainerItemType(rootContainerItemType,
                Lists.newArrayList(itemType, containerType, randomType, transientContainerType));
        API.createRootContainer(rootContainerId, rootContainerItemType);


        assertCreated(API.createContainer(clientId, createContainer(
                containerType, CONTAINER_LABEL, containerLabelType, rootContainerId), SuccessResponse.class));
        containerId = getItemsFromResponse(API.getItemFromImsByLabel(rootContainerId,
                new Label(containerLabelType, CONTAINER_LABEL)).getBody()).get(0).getId();

        assertCreated(API.createContainer(clientId, createTransientContainer(transientContainerType, BULK,
                transientContainerLabelType, rootContainerId), SuccessResponse.class));

        for (int i = 0; i < 3; ++i) {
            createUnitizableInIms("S" + (i + 1), 10.0 * (i + 1));
        }
        assertOk(API.addToContainer(clientId, createAddRequest(CONTAINER_LABEL, containerType, containerLabelType,
                rootContainerId, "3PL", STATE_MACHINE,
                createUnitizableRequests(itemLabelType, STATE_MACHINE, "S1", "S2")), SuccessResponse.class));
    }

    private void createUnitizableInIms(String label, double weight) {

        assertCreated(API.createContainer(clientId, createContainerWithWeight(itemType, label,
                itemLabelType, rootContainerId, weight), SuccessResponse.class));
        assertOk(API.updateItem(clientId, createUpdateRequest(itemType, label, rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "close"), SuccessResponse.class));
    }

    private void createUnitizableInImsWithoutWeight(String itemType, String label) {

        assertCreated(API.createContainer(clientId, createContainer(itemType, label,
                itemLabelType, rootContainerId), SuccessResponse.class));
        assertOk(API.updateItem(clientId, createUpdateRequest(itemType, label, rootContainerId, "3PL",
                itemLabelType, STATE_MACHINE, "close"), SuccessResponse.class));
    }

    private List<Item> getItemsFromResponse(String response) throws IOException {
        return objectMapper.readValue(response, GetItemResponse.class).getItems();
    }
}
