package com.ekart.facp.unitization.service.clients;

import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.mapper.ServiceEntityToClientRequestMapper;
import com.ekart.facp.unitization.service.dtos.clients.fsm.FsmInitialStateResponse;
import com.ekart.facp.unitization.service.dtos.clients.fsm.FsmNextStateResponse;
import com.ekart.facp.unitization.service.exceptions.clients.fsm.FsmBadRequestException;
import com.ekart.facp.unitization.service.exceptions.clients.fsm.FsmClientException;
import com.ekart.facp.unitization.service.exceptions.clients.fsm.InvalidStateMachineException;
import com.ekart.facp.unitization.service.exceptions.clients.fsm.InvalidTransitionException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static com.ekart.facp.unitization.common.ErrorCode.INVALID_STATE_TRANSITION;
import static com.ekart.facp.unitization.common.ErrorCode.SM_NOT_FOUND;
import static com.ekart.facp.unitization.common.ErrorCode.UNKNOWN_ERROR;
import static com.ekart.facp.unitization.service.utility.TestUtils.newHeader;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

/**
 * Created by anurag.gupta on 20/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class FsmClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ServiceEntityToClientRequestMapper mapper;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private HttpHeaders header;

    private static String baseUrl = "baseUrl";
    private static String stateMachineId = "stateMachineId";
    private String fsmUrl;
    private String fsmNextStateUrl;
    private FsmClient fsmClient;

    @Before
    public void setUp() throws Exception {
        fsmClient = new FsmClient(restTemplate, baseUrl, mapper, objectMapper);
        fsmUrl = "http://" + baseUrl + "/api/v1/statemachines/{stateMachineId}/states/initial";
        fsmNextStateUrl = "http://" + baseUrl
                + "/api/v1/statemachines/{identifier}/states/{state}/transitions/{transition}";
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfRestTemplateIsNull() {
        new FsmClient(null, baseUrl, mapper, objectMapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfBaseUrlIsNull() {
        new FsmClient(restTemplate, null, mapper, objectMapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfMapperIsNull() {
        new FsmClient(restTemplate, baseUrl, null, objectMapper);
    }

    @Test
    public void shouldReturnInitialState() throws IOException {
        String initialState = "initialState";
        FsmInitialStateResponse initialStateresponse = new FsmInitialStateResponse(initialState, 1);
        ResponseEntity<String> response = new ResponseEntity<>(initialStateresponse.toString(), HttpStatus.OK);

        when(restTemplate.exchange(Mockito.eq(fsmUrl),
                Mockito.eq(HttpMethod.GET), Mockito.<HttpEntity<String>>any(), Mockito.eq(String.class),
                Mockito.eq(stateMachineId))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(FsmInitialStateResponse.class))).
                thenReturn(initialStateresponse);

        assertThat(fsmClient.getInitialState(stateMachineId), is(initialState));
    }

    @Test(expected = InvalidStateMachineException.class)
    public void shouldThrowFsmClientExceptionWhenResponseIs400WithErrorCodeIsSMNotFound() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("SM doesnot exists", SM_NOT_FOUND.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(Mockito.eq(fsmUrl),
                Mockito.eq(HttpMethod.GET), Mockito.<HttpEntity<String>>any(), Mockito.eq(String.class),
                Mockito.eq(stateMachineId))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenReturn(badRequestResponse);

        fsmClient.getInitialState(stateMachineId);
    }


    @Test(expected = FsmBadRequestException.class)
    public void shouldThrowFsmClientExceptionWhenResponseIs400WithUnknownErrorCode() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("Mock Error", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(Mockito.eq(fsmUrl),
                Mockito.eq(HttpMethod.GET), Mockito.<HttpEntity<String>>any(), Mockito.eq(String.class),
                Mockito.eq(stateMachineId))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenReturn(badRequestResponse);

        fsmClient.getInitialState(stateMachineId);
    }

    @Test(expected = FsmClientException.class)
    public void shouldThrowFsmClientExceptionWhenResponseIs400WithUnknownErrorType() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("Unknown Error", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);

        when(restTemplate.exchange(Mockito.eq(fsmUrl),
                Mockito.eq(HttpMethod.GET), Mockito.<HttpEntity<String>>any(), Mockito.eq(String.class),
                Mockito.eq(stateMachineId))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenReturn(badRequestResponse);

        fsmClient.getInitialState(stateMachineId);
    }

    @Test
    public void shouldReturnNextState() throws IOException {
        String nextState = "nextState";
        FsmNextStateResponse nextStateResponse = new FsmNextStateResponse(nextState, 1);
        ResponseEntity<String> response = new ResponseEntity<>(nextStateResponse.toString(), HttpStatus.OK);

        when(restTemplate.exchange(fsmNextStateUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                stateMachineId, "state", "transition")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), FsmNextStateResponse.class)).thenReturn(nextStateResponse);

        assertThat(fsmClient.getNextState("state", "transition", stateMachineId), is(nextState));
    }

    @Test(expected = InvalidStateMachineException.class)
    public void shouldThrowFsmExceptionWhenResponseIs400WithErrorCodeIsSMNotFound() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("SM doesnot exists", SM_NOT_FOUND.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(fsmNextStateUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                stateMachineId, "state", "transition")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        fsmClient.getNextState("state", "transition", stateMachineId);
    }

    @Test(expected = InvalidTransitionException.class)
    public void shouldThrowFsmExceptionWhenResponseIs400WithErrorCodeIsINVALIDTRANSITION() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("SM doesnot exists", INVALID_STATE_TRANSITION.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(fsmNextStateUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                stateMachineId, "state", "transition")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).
                thenReturn(badRequestResponse);

        fsmClient.getNextState("state", "transition", stateMachineId);
    }

    @Test(expected = FsmBadRequestException.class)
    public void shouldThrowFsmExceptionWhenResponseIs400WithUnknownErrorCode() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("Unknown error", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), HttpStatus.BAD_REQUEST);

        when(restTemplate.exchange(fsmNextStateUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                stateMachineId, "state", "transition")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        fsmClient.getNextState("state", "transition", stateMachineId);
    }

    @Test(expected = FsmClientException.class)
    public void shouldThrowFsmExceptionWhenResponseIs400WithUnknownErrorType() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("Unknown Error", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);

        when(restTemplate.exchange(fsmNextStateUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                stateMachineId, "state", "transition")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenReturn(badRequestResponse);

        fsmClient.getNextState("state", "transition", stateMachineId);
    }

    @Test(expected = FsmClientException.class)
    public void shouldThrowFsmExceptionWhenResponseIs400IfResponseIsNotInProperFormat() throws IOException {
        ResponseEntity<String> response = new ResponseEntity<>("unknown_string", INTERNAL_SERVER_ERROR);

        when(restTemplate.exchange(fsmNextStateUrl, HttpMethod.GET, new HttpEntity<>(newHeader()), String.class,
                stateMachineId, "state", "transition")).thenReturn(response);
        when(objectMapper.readValue(response.getBody(), ErrorMessage.class)).thenThrow(new IOException());

        fsmClient.getNextState("state", "transition", stateMachineId);
    }

    @Test(expected = FsmClientException.class)
    public void shouldThrowFsmClientExceptionWhenEncountersIOExceptionWhileParsing() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("Unknown Error", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);

        when(restTemplate.exchange(Mockito.eq(fsmUrl),
                Mockito.eq(HttpMethod.GET), Mockito.<HttpEntity<String>>any(), Mockito.eq(String.class),
                Mockito.eq(stateMachineId))).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenThrow(new IOException());

        fsmClient.getInitialState(stateMachineId);
    }
}

