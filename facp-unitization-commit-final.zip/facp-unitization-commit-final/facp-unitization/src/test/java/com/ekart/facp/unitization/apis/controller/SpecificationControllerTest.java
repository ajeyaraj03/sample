package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.dtos.Specification;
import com.ekart.facp.unitization.apis.dtos.SpecificationCreationRequest;
import com.ekart.facp.unitization.apis.dtos.SpecificationCreationResponse;
import com.ekart.facp.unitization.apis.dtos.SuccessResponse;
import com.ekart.facp.unitization.apis.mapper.ApiDtoToServiceEntityMapper;
import com.ekart.facp.unitization.apis.util.UUIDGenerator;
import com.ekart.facp.unitization.service.SpecificationService;
import com.ekart.facp.unitization.service.entities.SpecificationUpdationRequest;
import com.ekart.facp.unitization.service.exceptions.SpecificationNotFoundException;
import com.ekart.facp.unitization.service.utility.TenantContext;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.collection.IsIterableContainingInAnyOrder.containsInAnyOrder;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.*;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by anuj.chaudhary on 20/04/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpecificationControllerTest {
    private static final String TENANT = "mockTenant";
    private static final String SPECIFICATION_ID = "mockSpecificationId";
    @Mock
    private SpecificationService specificationService;
    @Mock
    private ApiDtoToServiceEntityMapper mapper;
    @Mock
    private UUIDGenerator uuidGenerator;
    @Mock
    private TenantContext tenantContext;
    private SpecificationController specificationController;

    @Before
    public void setUp() throws Exception {
        specificationController = new SpecificationController(specificationService, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionDuringCreationIfSpecificationServiceIsNull() {

        new SpecificationController(null, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionDuringCreationIfMapperIsNull() {

        new SpecificationController(specificationService, null);
    }

    @Test
    public void shouldThrowManadatoryFieldsValidationsCreateFlow() {
        SpecificationCreationRequest specificationRequest =
                new SpecificationCreationRequest();

        // validate the input
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<SpecificationCreationRequest>> violations =
                validator.validate(specificationRequest);
        List<String> attributeList = violations.stream().map(p -> p.getPropertyPath()
                .toString()).collect(Collectors.toList());

        assertThat(violations.size(), is(2));
        assertThat(attributeList, containsInAnyOrder("createdBy", "type"));


    }

    @Test
    public void shouldThrowManadatoryFieldsValidationsUpdateFlow() {
        com.ekart.facp.unitization.apis.dtos.SpecificationUpdateRequest specificationRequest =
                new com.ekart.facp.unitization.apis.dtos.SpecificationUpdateRequest();

        // validate the input
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<com.ekart.facp.unitization.apis.dtos.SpecificationUpdateRequest>> violations =
                validator.validate(specificationRequest);

        assertThat(violations.size(), is(1));
        assertThat("updatedBy", is(String.join("-", violations.stream().map(p -> p.getPropertyPath()
                .toString()).collect(Collectors.toList()))));

    }

    @Test
    public void shouldCreateASpecification() {
        SpecificationCreationRequest specificationRequest =
                mock(SpecificationCreationRequest.class);
        com.ekart.facp.unitization.service.entities.SpecificationCreationRequest specificationCreationRequest =
                mock(com.ekart.facp.unitization.service.entities.SpecificationCreationRequest.class);
        UUID randomId = UUID.randomUUID();

        when(uuidGenerator.generate()).thenReturn(randomId);
        when(mapper.specificationCreationRequestToSpecificationCreationRequestEntity(specificationRequest))
                .thenReturn(specificationCreationRequest);
        when(specificationService.create(
                Mockito.<TenantContext>anyObject(),
                Mockito.<com.ekart.facp.unitization.service.entities.SpecificationCreationRequest>anyObject()))
                .thenReturn(randomId.toString());
        ResponseEntity<SpecificationCreationResponse> result = specificationController
                .createSpecification(specificationRequest, TENANT);

        assertReflectionEquals(result, BaseController.created(
                new SpecificationCreationResponse(randomId.toString())));
    }

    @Test
    public void shouldUpdateTheSpecification() {
        com.ekart.facp.unitization.apis.dtos.SpecificationUpdateRequest specificationRequest =
                mock(com.ekart.facp.unitization.apis.dtos.SpecificationUpdateRequest.class);
        SpecificationUpdationRequest specificationUpdationRequest = mock(SpecificationUpdationRequest.class);

        when(mapper.specificationUpdateRequestToSpecificationUpdationEntity(SPECIFICATION_ID, specificationRequest))
                .thenReturn(specificationUpdationRequest);
        ResponseEntity<?> result = specificationController.updateSpecification(SPECIFICATION_ID, TENANT,
                specificationRequest);

        verify(specificationService, times(1)).update(Mockito.<TenantContext>anyObject(),
                Mockito.<SpecificationUpdationRequest>anyObject());
        assertReflectionEquals(result, BaseController.ok(new SuccessResponse()));
    }

    @Test
    public void shouldDeleteTheSpecification() {
        ResponseEntity<?> result = specificationController.removeSpecification(Mockito.anyString(),
                Mockito.anyString());
        verify(specificationService, times(1)).remove(Mockito.<TenantContext>anyObject(), Mockito.anyString());
        assertReflectionEquals(result, BaseController.ok(new SuccessResponse()));
    }

    @Test(expected = SpecificationNotFoundException.class)
    public void shouldReturnBadRequestIfSpecificationDoesNotExist() {
        doThrow(new SpecificationNotFoundException(null))
                .when(specificationService).get(Mockito.<TenantContext>anyObject(), Mockito.anyString());
        specificationController.getById(SPECIFICATION_ID, TENANT);
    }

    @Test
    public void shouldReturnSpecificationIfItExists() {
        com.ekart.facp.unitization.service.entities.Specification specification = mock(
                com.ekart.facp.unitization.service.entities.Specification.class);
        Specification specificationResponse = mock(Specification.class);

        when(specificationService.get(Mockito.<TenantContext>anyObject(), Mockito.anyString()))
                .thenReturn(specification);
        when(mapper.specificationEntityToSpecificationResponse(specification)).thenReturn(specificationResponse);
        ResponseEntity<?> result = specificationController.getById(SPECIFICATION_ID, TENANT);

        assertReflectionEquals(result, BaseController.ok(specificationResponse));
    }

}
