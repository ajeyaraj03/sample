package com.ekart.facp.unitization.apis.controller;

import com.ekart.facp.unitization.apis.dtos.Specification;
import com.ekart.facp.unitization.apis.mapper.ApiDtoToServiceEntityMapper;
import com.ekart.facp.unitization.service.SpecificationService;
import com.ekart.facp.unitization.service.utility.TenantContext;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.ResponseEntity;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by anuj.chaudhary on 26/04/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class SpecificationSearchControllerTest {
    private static final String TENANT = "mockTenant";
    private static final String TYPE = "mockType";
    @Mock
    private SpecificationService specificationService;
    @Mock
    private ApiDtoToServiceEntityMapper mapper;
    private SpecificationSearchController specificationSearchController;

    @Before
    public void setUp() throws Exception {
        specificationSearchController = new SpecificationSearchController(specificationService, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionDuringCreationIfSpecificationServiceIsNull() {

        new SpecificationSearchController(null, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionDuringCreationIfMapperIsNull() {

        new SpecificationSearchController(specificationService, null);
    }

    @Test
    public void shouldReturnSpecificationIfActiveSpecificationExistsForTenantAndType() {
        com.ekart.facp.unitization.service.entities.Specification specification = mock(
                com.ekart.facp.unitization.service.entities.Specification.class);
        Specification specificationResponse = mock(Specification.class);
        when(specificationService.getByType(Mockito.<TenantContext>anyObject(), Mockito.anyString()))
                .thenReturn(specification);
        when(mapper.specificationEntityToSpecificationResponse(specification)).thenReturn(specificationResponse);
        ResponseEntity<?> result = specificationSearchController.getActiveSpecificationByType(TENANT, TYPE);
        assertReflectionEquals(result, BaseController.ok(specificationResponse));
    }

    @Test
    public void shouldReturnSpecificationIfInactiveSpecificationExistsForTenantAndType() {
        com.ekart.facp.unitization.service.entities.Specification specification = mock(
                com.ekart.facp.unitization.service.entities.Specification.class);
        Specification specificationResponse = mock(Specification.class);
        when(specificationService.getInactiveByType(Mockito.<TenantContext>anyObject(), Mockito.anyString()))
                .thenReturn(specification);
        when(mapper.specificationEntityToSpecificationResponse(specification)).thenReturn(specificationResponse);
        ResponseEntity<?> result = specificationSearchController
                .getInactiveSpecificationByType(TENANT, TYPE);
        assertReflectionEquals(result, BaseController.ok(specificationResponse));
    }
}
