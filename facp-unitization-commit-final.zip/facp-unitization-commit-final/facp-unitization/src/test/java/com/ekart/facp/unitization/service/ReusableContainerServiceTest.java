package com.ekart.facp.unitization.service;

import com.ekart.facp.unitization.service.clients.FsmClient;
import com.ekart.facp.unitization.service.clients.ImsClient;
import com.ekart.facp.unitization.service.clients.LabelServiceClient;
import com.ekart.facp.unitization.service.dtos.Container;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemLabel;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemStatus;
import com.ekart.facp.unitization.service.exceptions.ContainerAlreadyExistsException;
import com.ekart.facp.unitization.service.exceptions.clients.label_service.LabelAlreadyExists;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.ekart.facp.unitization.service.validators.SpecificationAttributesValidator;
import com.ekart.facp.unitization.service.validators.UnitizationValidator;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.*;

/**
 * Created by anurag.gupta on 06/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class ReusableContainerServiceTest {

    @Mock
    private ImsClient imsClient;

    @Mock
    private FsmClient fsmClient;

    @Mock
    private LabelServiceClient labelServiceClient;

    @Mock
    private SpecificationAttributesValidator specificationAttributesValidator;

    @Mock
    private UnitizationValidator unitizationValidator;

    private ReusableContainerService containerService;
    private static String labelType  = "labelType";
    private static String labelValue = "labelValue";
    private static String status = "status";
    private static String rootContainerId = "rootContainerId";
    private static String containerId = "containerId";
    private static String stateMachineId = "stateMachineId";
    private static String flowContext = "flowContext";
    private static String appId = "appId";
    private static String id = "id";
    private static String createdByDocumentType = "createdByDocumentType";
    private static String createdByDocumentId = "createdByDocumentId";
    private static String type = "type";
    private static BigDecimal quantity = BigDecimal.valueOf(1);
    private static String uom = "uom";
    private static long version = 1;
    private static long createdAtEpoch = 12345;
    private static long updatedAtEpoch = 123456;
    private static final String TENANT = "tenant";
    private static String createdBy = "createdBy";
    private static String idempotenceKey = "idempotenceKey";

    private TenantContext tenantContext;
    private Map<String, ItemStatus> statuses;
    private String processOwner;
    private Container container;
    private com.ekart.facp.unitization.service.dtos.ItemLabel label;
    private Item item;
    private ItemStatus itemStatus;
    private ItemLabel itemLabel;

    @Before
    public void setup() {
        processOwner = String.join("_", flowContext, appId, type);
        label = new com.ekart.facp.unitization.service.dtos.ItemLabel();
        label.setValue(labelValue);
        label.setType(labelType);
        processOwner = String.join("_", flowContext, appId, type);
        statuses = new HashMap<String, ItemStatus>();
        statuses.put(processOwner, itemStatus);
        containerService = new ReusableContainerService(imsClient, fsmClient, specificationAttributesValidator,
                unitizationValidator, labelServiceClient);
        itemLabel = new ItemLabel(labelType, labelValue);
        itemStatus = new ItemStatus(processOwner, status);
        container = new Container();
        container.setFacilityId(rootContainerId);
        container.setLabel(label);
        container.setStateMachineId(stateMachineId);
        container.setAppId(appId);
        container.setFlowContext(flowContext);
        container.setType(type);
        container.setIdempotenceKey(idempotenceKey);
        container.setCreatedBy(createdBy);
        tenantContext = new TenantContext(TENANT);
        item = new Item(id, createdByDocumentType, createdByDocumentId, type, containerId, rootContainerId, quantity,
                uom, ImmutableMap.<String, Object>of(), ImmutableMap.<String, ItemAttribute>of(),
                ImmutableMap.<String, ItemAttribute>of(), ImmutableMap.<String, ItemStatus>of(processOwner, itemStatus),
                ImmutableMap.<String, ItemLabel>of(labelType, itemLabel), ImmutableMap.<String, ItemAttribute>of(),
                version, createdAtEpoch, updatedAtEpoch);
    }

    @Test(expected = ContainerAlreadyExistsException.class)
    public void shouldThrowContainerAlreadyExistsException() {
        String mockMessage = "mockMessage";
        doThrow(new LabelAlreadyExists(mockMessage)).when(labelServiceClient).createLabelMapping(TENANT,
                rootContainerId, type, createdBy, idempotenceKey, Lists.newArrayList(label));
        when(imsClient.getItemsByLabel(rootContainerId, label)).thenReturn(Lists.newArrayList(item));

        containerService.createContainer(tenantContext, container);
        verify(imsClient, never()).createItem(status, processOwner, container);
    }

    @Test
    public void shouldReturnContainerIdWhenCreateIsInvoked() {
        when(fsmClient.getInitialState(stateMachineId)).thenReturn(status);
        when(imsClient.getItemsByLabel(rootContainerId, label)).thenReturn(Lists.newArrayList());
        when(imsClient.createItem(status, processOwner, container)).thenReturn(containerId);

        assertThat(containerService.createContainer(tenantContext, container), is(containerId));
        verify(labelServiceClient).createLabelMapping(TENANT, rootContainerId, type, createdBy, idempotenceKey,
                Lists.newArrayList(label));
    }
}
