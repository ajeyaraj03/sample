package com.ekart.facp.unitization.dal;

import com.ekart.facp.unitization.apis.Application;
import com.ekart.facp.unitization.apis.config.spring.ApplicationConfig;
import com.ekart.facp.unitization.apis.util.UUIDGenerator;
import com.ekart.facp.unitization.dal.models.Specification;
import com.google.common.collect.ImmutableMap;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import javax.inject.Inject;
import java.util.Optional;

import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by ajeya.hb on 20/04/16.
 */
@RunWith(SpringJUnit4ClassRunner.class)

@SpringApplicationConfiguration(classes = {Application.class, ApplicationConfig.class})
@WebAppConfiguration
public class SpecificationRepositoryTest {
    @Inject
    private SpecificationRepository specificationRepository;
    private Specification specification;

    @Before
    public void setUp() {
        specification = createSpecification(true);
        specificationRepository.insertAndFlush(specification);
    }

    @Test
    public void createTest() {
        Specification newSpecification = createSpecification(true);
        specificationRepository.insertAndFlush(newSpecification);

        Optional<Specification> specData = specificationRepository.findById(newSpecification.getId());
        assertReflectionEquals(specData.get(), newSpecification);
    }

    @Test
    public void findByIdTest() {
        Optional<Specification> specData = specificationRepository.findById(specification.getId());
        assertReflectionEquals(specData.get(), specification);
    }

    @Test
    public void findByTenantIdAndTypeTest() {
        assertReflectionEquals(Optional.ofNullable(specificationRepository.findByTenantAndType(
                specification.getTenant(), specification.getType())).get(), specification);
    }

    @Test
    public void updateTest() {

        Specification spec = specificationRepository.findById(specification.getId()).get();
        spec.setActive(false);

        specificationRepository.saveAndFlush(spec);
        Optional<Specification> specData = specificationRepository.findById(specification.getId());
        assertThat(specData.get().isActive(), is(spec.isActive()));

    }

    private Specification createSpecification(boolean active) {
        Specification spec = new Specification();
        spec.setTenant(randomAlphabetic(10));
        spec.setId(new UUIDGenerator().generate().toString());
        spec.setType(randomAlphabetic(10));
        spec.setArchived(false);
        spec.setActive(active);
        spec.setUpdatedBy(randomAlphabetic(10));
        spec.setCreatedBy(randomAlphabetic(10));
        spec.setReusable(false);
        spec.setAttributes(ImmutableMap.of(randomAlphabetic(10), randomAlphabetic(10)));
        return spec;
    }
}
