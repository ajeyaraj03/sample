package com.ekart.facp.unitization.service.clients;

import com.ekart.facp.unitization.apis.dtos.ErrorMessage;
import com.ekart.facp.unitization.apis.mapper.ServiceEntityToClientRequestMapper;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import com.ekart.facp.unitization.service.dtos.clients.label_service.response.LabelMappingCreateResponse;
import com.ekart.facp.unitization.service.exceptions.clients.label_service.LabelServiceBadRequestException;
import com.ekart.facp.unitization.service.exceptions.clients.label_service.LabelServiceClientException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import static com.ekart.facp.unitization.common.ErrorCode.UNKNOWN_ERROR;
import static org.mockito.Mockito.when;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

/**
 * Created by anurag.gupta on 14/07/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class LabelServiceClientTest {

    @Mock
    private RestTemplate restTemplate;

    @Mock
    private ServiceEntityToClientRequestMapper mapper;

    @Mock
    private HttpHeaders header;

    @Mock
    private ObjectMapper objectMapper;

    private String labelServiceUrl;
    private LabelServiceClient labelServiceClient;
    private Map<String, String> labels;
    private ItemLabel label;

    private static String entityType = "entityType";
    private static String facilityId = "facilityId";
    private static String labelValue = "labelValue";
    private static String labelType = "labelType";
    private static String tenant = "tenant";
    private static String baseUrl = "baseUrl";
    private static String createdBy = "createdBy";
    private static String type = "type";
    private static String idempotenceKey = "idempotenceKey";


    @Before
    public void setUp() throws Exception {
        labelServiceClient = new LabelServiceClient(restTemplate, baseUrl, mapper, objectMapper);
        labelServiceUrl = "http://" + baseUrl + "/api/v1/{facility_id}/mapping/{entity_type}";
        label = new ItemLabel();
        label.setType(labelType);
        label.setValue(labelValue);
        labels = new HashMap<String, String>();
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfRestTemplateIsNull() {
        new FsmClient(null, baseUrl, mapper, objectMapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfBaseUrlIsNull() {
        new FsmClient(restTemplate, null, mapper, objectMapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfMapperIsNull() {
        new FsmClient(restTemplate, baseUrl, null, objectMapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfObjectMapperIsNull() {
        new FsmClient(restTemplate, baseUrl, mapper, null);
    }

    @Test
    public void shouldCreateLabelMappingInLabelService() {
        LabelMappingCreateResponse labelCreateResponse = new LabelMappingCreateResponse(facilityId, labels, entityType);
        ResponseEntity<String> response = new ResponseEntity<>(labelCreateResponse.toString(), HttpStatus.CREATED);

        when(restTemplate.exchange(Mockito.eq(labelServiceUrl),
                Mockito.eq(HttpMethod.POST), Mockito.<HttpEntity<String>>any(), Mockito.eq(String.class),
                Mockito.anyString(), Mockito.anyString())).thenReturn((ResponseEntity)response);

        labelServiceClient.createLabelMapping(tenant, facilityId, type, createdBy, idempotenceKey,
                Lists.newArrayList(label));
    }

    @Test(expected = LabelServiceBadRequestException.class)
    public void shouldLabelServiceBadRequestExceptionWhileCreatingLabel() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), BAD_REQUEST);

        when(restTemplate.exchange(Mockito.eq(labelServiceUrl),
                Mockito.eq(HttpMethod.POST), Mockito.<HttpEntity<String>>any(), Mockito.eq(String.class),
                Mockito.anyString(), Mockito.anyString())).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenReturn(badRequestResponse);

        labelServiceClient.createLabelMapping(tenant, facilityId, type, createdBy, idempotenceKey,
                Lists.newArrayList(label));
    }

    @Test(expected = LabelServiceClientException.class)
    public void shouldLabelServiceClientExceptionWhileCreatingLabel() throws IOException {
        ErrorMessage badRequestResponse = new ErrorMessage("mockMessage", UNKNOWN_ERROR.name());
        ResponseEntity<String> response = new ResponseEntity<>(badRequestResponse.toString(), INTERNAL_SERVER_ERROR);

        when(restTemplate.exchange(Mockito.eq(labelServiceUrl),
                Mockito.eq(HttpMethod.POST), Mockito.<HttpEntity<String>>any(), Mockito.eq(String.class),
                Mockito.anyString(), Mockito.anyString())).thenReturn((ResponseEntity)response);
        when(objectMapper.readValue(Mockito.anyString(), Mockito.eq(ErrorMessage.class))).
                thenReturn(badRequestResponse);

        labelServiceClient.createLabelMapping(tenant, facilityId, type, createdBy, idempotenceKey,
                Lists.newArrayList(label));
    }

}
