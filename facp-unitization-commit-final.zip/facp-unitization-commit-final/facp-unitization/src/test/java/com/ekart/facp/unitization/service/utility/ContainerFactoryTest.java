package com.ekart.facp.unitization.service.utility;

import com.ekart.facp.unitization.common.enums.ContainerType;
import com.ekart.facp.unitization.service.DispensibleContainerService;
import com.ekart.facp.unitization.service.ReusableContainerService;
import com.ekart.facp.unitization.service.UnitizationService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import static com.ekart.facp.unitization.common.enums.ContainerType.DISPENSIBLE;
import static com.ekart.facp.unitization.common.enums.ContainerType.REUSABLE;
import static org.junit.Assert.assertTrue;

/**
 * Created by anurag.gupta on 08/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class ContainerFactoryTest {

    @Mock
    private ReusableContainerService reusableContainerService;

    @Mock
    private DispensibleContainerService dispensibleContainerService;

    private ContainerFactory containerFactory;

    @Before
    public void setup() {
        containerFactory = new ContainerFactory(reusableContainerService, dispensibleContainerService);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfReusableContainerServiceIsNull() {

        new ContainerFactory(null, dispensibleContainerService);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfDispensibleContainerServiceIsNull() {
        new ContainerFactory(reusableContainerService, null);
    }

    @Test
    public void shouldCallReusableContainerServiceWhenInvokedWithTypeReusable() {
        ContainerType containerType = REUSABLE;
        UnitizationService service = containerFactory.getService(containerType);
        assertTrue(service instanceof ReusableContainerService);
    }

    @Test
    public void shouldCallDispensibleContainerServiceWhenInvokedWithTypeDispensible() {
        ContainerType containerType = DISPENSIBLE;
        UnitizationService service = containerFactory.getService(containerType);
        assertTrue(service instanceof DispensibleContainerService);
    }

}
