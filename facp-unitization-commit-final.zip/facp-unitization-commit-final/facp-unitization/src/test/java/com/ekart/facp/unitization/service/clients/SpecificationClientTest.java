package com.ekart.facp.unitization.service.clients;

import com.ekart.facp.unitization.service.SpecificationService;
import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.utility.TenantContext;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.when;


/**
 * Created by anurag.gupta on 05/07/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class SpecificationClientTest {

    @Mock
    private SpecificationService specificationService;

    @Mock
    private Specification specification;

    private static String type = "type";
    private static String tenant = "tenant";
    private SpecificationClient specificationClient;
    private TenantContext tenantContext;


    @Before
    public void setUp() throws Exception {
        specificationClient = new SpecificationClient(specificationService);
        tenantContext = new TenantContext(tenant);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfSpecificationServiceIsNull() {
        specificationClient = new SpecificationClient(null);
    }

    @Test
    public void shouldReturnSpecification() {
        when(specificationService.getByType(Mockito.<TenantContext>anyObject(), Mockito.anyString())).
                thenReturn(specification);
        assertThat(specificationClient.getSpecification(tenantContext, type),
                is(specification));
    }


}
