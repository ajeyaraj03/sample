package com.ekart.facp.unitization.dal.mysql.custom;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.Id;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/**
 * @author vijay.daniel
 */
@RunWith(MockitoJUnitRunner.class)
public class InsertSupportedJpaRepositoryImplTest {

    @Mock
    private EntityManager entityManager;

    @Mock
    private JpaEntityInformation<TestEntity, ?> jpaEntityInformation;

    private InsertSupportedJpaRepository<TestEntity, Integer> repo;

    @Before
    public void setUp() {

        // This stub is necessary to complete the construction of
        // SimpleJpaRepository
        when(entityManager.getDelegate()).thenReturn(new TestEntity());

        repo = new InsertSupportedJpaRepositoryImpl<>(jpaEntityInformation, entityManager);
    }

    @Test
    public void shouldInsertRow() {

        TestEntity entity = new TestEntity();
        repo.insert(entity);

        verify(entityManager).persist(entity);
    }

    @Test
    public void shouldInsertAndFlushRow() {

        TestEntity entity = new TestEntity();
        repo.insertAndFlush(entity);

        verify(entityManager).persist(entity);
        verify(entityManager).flush();
    }

    @Entity
    public static class TestEntity {

        @Id
        private Integer id;
    }
}
