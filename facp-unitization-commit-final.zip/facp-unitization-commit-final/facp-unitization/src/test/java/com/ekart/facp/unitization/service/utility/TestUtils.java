package com.ekart.facp.unitization.service.utility;

import com.ekart.facp.unitization.service.dtos.*;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import org.springframework.http.HttpHeaders;

import javax.ws.rs.core.MediaType;
import java.util.List;

import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.apache.commons.lang.RandomStringUtils.randomAlphanumeric;

/**
 * Created by avinash.r on 18/07/16.
 */
public class TestUtils {

    public static AddRequest createAddRequest(String containerLabel, String containerType, String containerLabelType,
                                              String facilityId, String flowContext, String stateMachineId,
                                              List<Unitizable> unitizables) {
        AddRequest addRequest = new AddRequest();
        addRequest.setIdempotenceKey(randomAlphanumeric(20));
        addRequest.setAppId("MH");
        addRequest.setCreatedByEntityType("entityType");
        addRequest.setCreatedByEntityId("entityId");
        addRequest.setContainerLabel(containerLabel);
        addRequest.setContainerLabelType(containerLabelType);
        addRequest.setContainerType(containerType);
        addRequest.setFacilityId(facilityId);
        addRequest.setFlowContext(flowContext);
        addRequest.setStateMachineId(stateMachineId);
        addRequest.setUnitizables(unitizables);
        addRequest.setRequestedBy("some_random_guy_moving");
        return addRequest;
    }

    public static UpdateRequest createUpdateRequest(String type, String label, String facilityId, String flowContext,
                                                    String labelType, String stateMachineId, String transitionName) {

        UpdateRequest updateRequest = new UpdateRequest();
        UpdateRequestItem updateRequestItem = new UpdateRequestItem();
        updateRequest.setIdempotenceKey(randomAlphabetic(20));
        updateRequest.setAppId("MH");
        updateRequest.setCreatedByEntityType("entityType");
        updateRequest.setCreatedByEntityId("entityId");
        updateRequest.setFacilityId(facilityId);
        updateRequest.setRequestedBy("some_random_guy");

        updateRequestItem.setType(type);
        updateRequestItem.setLabel(label);
        updateRequest.setFlowContext(flowContext);
        updateRequestItem.setLabelType(labelType);
        updateRequestItem.setStateMachineId(stateMachineId);
        updateRequestItem.setTransitionName(transitionName);
        updateRequestItem.setLabelsToBeAdded(ImmutableList.of(new ItemLabel(randomAlphabetic(8), randomAlphabetic(8))));

        updateRequest.setUpdateRequestItems(Lists.newArrayList(updateRequestItem));
        return updateRequest;
    }

    public static List<Unitizable> createUnitizableRequests(String labelType, String stateMachineId, String... labels) {

        List<Unitizable> unitizables = Lists.newArrayListWithExpectedSize(labels.length);
        for (String label : labels) {
            Unitizable unitizable = new Unitizable();
            unitizable.setLabelType(labelType);
            unitizable.setLabel(label);
            unitizable.setStateMachineId(stateMachineId);
            unitizables.add(unitizable);
        }
        return unitizables;
    }

    public static HttpHeaders newHeader() {
        HttpHeaders header = new HttpHeaders();
        header.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON);
        return header;
    }
}
