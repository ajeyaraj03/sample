DROP TABLE IF EXISTS `specifications`;
CREATE TABLE `specifications` (
  `id` varchar(255) NOT NULL DEFAULT '',
  `tenant` varchar(20) NOT NULL,
  `type` varchar(30) NOT NULL,
  `reusable` tinyint(1) NOT NULL DEFAULT '0',
  `attributes` longtext NOT NULL,
  `created_by` varchar(30) NOT NULL,
  `updated_by` varchar(30) NOT NULL,
  `created_at_epoch` BIGINT(20) NOT NULL,
  `updated_at_epoch` BIGINT(20) NOT NULL,
  `version` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tenant_and_type` (`tenant`,`type`)
);

