package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.UPDATE_REQUEST_BULK_SIZE;

/**
 * Created by avinash.r on 13/07/16.
 */
@ApiModel
public class UpdateRequest {

    @ApiModelProperty(name = "idempotence_key", value = "The idempotence key for this operation. The idempotence key "
            + "is enforced at the API level")
    @JsonProperty(value = "idempotence_key")
    @NotNull(message = "{container.idempotenceKey.notnull}")
    private String idempotenceKey;

    @ApiModelProperty(name = "created_by_entity_type", value = "The entity type against which the container is created")
    @JsonProperty(value = "created_by_entity_type")
    @NotNull(message = "{container.createdByEntityType.notnull}")
    private String createdByEntityType;

    @ApiModelProperty(name = "created_by_entity_id", value = "The entity id against which the container is created")
    @JsonProperty(value = "created_by_entity_id")
    @NotNull(message = "{container.createdByEntityId.notnull}")
    private String createdByEntityId;

    @ApiModelProperty(name = "facility_id", value = "The facility in which the container is created")
    @JsonProperty(value = "facility_id")
    @NotNull(message = "{container.facilityId.notnull}")
    private String facilityId;

    @ApiModelProperty(name = "app_id", value = "The machine which requested this operation")
    @JsonProperty(value = "app_id")
    @NotNull(message = "{container.appId.notnull}")
    private String appId;

    @ApiModelProperty(name = "flow_context", value = "The context of the flow for which "
            + "the container is created")
    @JsonProperty(value = "flow_context")
    @NotNull(message = "{container.flowContext.notnull}")
    private String flowContext;

    //we are providing bulk API but for now we are enabling it only for one, implementation will be done later.
    @ApiModelProperty(name = "update_request_items", value = "The update_request_items are the items to be updated")
    @JsonProperty(value = "update_request_items")
    @NotEmpty(message = "{container.updateRequestItems.notempty}")
    @Size(max = UPDATE_REQUEST_BULK_SIZE, message = "{container.updateRequestItems.size}")
    @Valid
    private List<UpdateRequestItem> updateRequestItems;

    @ApiModelProperty(name = "requested_by", value = "The requested_by is the user who requested this operation.")
    @JsonProperty(value = "requested_by")
    @NotNull(message = "{container.requestedBy.notnull}")
    private String requestedBy;

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public String getCreatedByEntityType() {
        return createdByEntityType;
    }

    public void setCreatedByEntityType(String createdByEntityType) {
        this.createdByEntityType = createdByEntityType;
    }

    public String getCreatedByEntityId() {
        return createdByEntityId;
    }

    public void setCreatedByEntityId(String createdByEntityId) {
        this.createdByEntityId = createdByEntityId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public List<UpdateRequestItem> getUpdateRequestItems() {
        return updateRequestItems;
    }

    public void setUpdateRequestItems(List<UpdateRequestItem> updateRequestItems) {
        this.updateRequestItems = updateRequestItems;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }

    public String getFlowContext() {
        return flowContext;
    }

    public void setFlowContext(String flowContext) {
        this.flowContext = flowContext;
    }

    @Override
    public String toString() {
        return "UpdateRequest{" + "idempotenceKey='" + idempotenceKey + '\''
                + ", createdByEntityType='" + createdByEntityType + '\''
                + ", createdByEntityId='" + createdByEntityId + '\'' + ", facilityId='" + facilityId + '\''
                + ", appId='" + appId + '\'' + ", flowContext='" + flowContext + '\''
                + ", updateRequestItems=" + updateRequestItems + ", requestedBy='" + requestedBy + '\'' + '}';
    }
}
