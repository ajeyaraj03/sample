package com.ekart.facp.unitization.apis.mapper;

/**
 * Created by ajeya.hb on 24/03/16.
 */

import com.ekart.facp.unitization.apis.dtos.*;
import com.ekart.facp.unitization.service.dtos.Container;
import com.ekart.facp.unitization.service.dtos.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import com.ekart.facp.unitization.service.entities.SpecificationCreationRequest;
import com.ekart.facp.unitization.service.entities.SpecificationUpdationRequest;
import org.mapstruct.Mapper;
import org.springframework.stereotype.Component;

@Component
@Mapper(componentModel = "spring")
public interface ApiDtoToServiceEntityMapper {

    SpecificationCreationRequest specificationCreationRequestToSpecificationCreationRequestEntity(
            com.ekart.facp.unitization.apis.dtos.SpecificationCreationRequest specificationRequest);

    SpecificationUpdationRequest specificationUpdateRequestToSpecificationUpdationEntity(
            String id, com.ekart.facp.unitization.apis.dtos.SpecificationUpdateRequest specificationRequest);

    Specification specificationEntityToSpecificationResponse(com.ekart.facp.unitization.service.entities.Specification
                                                                     specification);

    Container unitizationRequestToContainerServiceEntity(ContainerCreateRequest containerCreateRequestRequest);

    ItemAttribute attributeToItemAttribute(Attribute attribute);

    ItemLabel labelToItemLabel(Label label);

    com.ekart.facp.unitization.service.dtos.UpdateRequestItem apiToServiceUpdateRequestItem(
            UpdateRequestItem updateRequestItem);

    com.ekart.facp.unitization.service.dtos.UpdateRequest apiToServiceUnitizationUpdateRequest(
            UpdateRequest updateRequest);

    com.ekart.facp.unitization.service.dtos.Unitizable apiToServiceUnitizable(Unitizable unitizable);

    com.ekart.facp.unitization.service.dtos.AddRequest apiToServiceUnitizationMoveRequest(AddRequest addRequest);
}
