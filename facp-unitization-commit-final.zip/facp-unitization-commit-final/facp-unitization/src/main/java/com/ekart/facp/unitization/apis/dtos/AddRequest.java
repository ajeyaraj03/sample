package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;

import static com.ekart.facp.unitization.apis.constants.ApiConstants.MAX_UNITIZABLES_TO_BE_ADDED;

/**
 * Created by avinash.r on 13/07/16.
 */

@ApiModel
public class AddRequest {

    @ApiModelProperty(name = "idempotence_key", value = "The idempotence key for this operation. The idempotence key "
            + "is enforced at the API level")
    @JsonProperty(value = "idempotence_key")
    @NotNull(message = "{container.idempotenceKey.notnull}")
    private String idempotenceKey;

    @ApiModelProperty(name = "created_by_entity_type", value = "The entity type against which the container is created")
    @JsonProperty(value = "created_by_entity_type")
    @NotNull(message = "{container.createdByEntityType.notnull}")
    private String createdByEntityType;

    @ApiModelProperty(name = "created_by_entity_id", value = "The entity id against which the container is created")
    @JsonProperty(value = "created_by_entity_id")
    @NotNull(message = "{container.createdByEntityId.notnull}")
    private String createdByEntityId;

    @ApiModelProperty(name = "facility_id", value = "The facility in which the container is created")
    @JsonProperty(value = "facility_id")
    @NotNull(message = "{container.facilityId.notnull}")
    private String facilityId;

    @ApiModelProperty(name = "app_id", value = "The machine which requested this operation")
    @JsonProperty(value = "app_id")
    @NotNull(message = "{container.appId.notnull}")
    private String appId;

    @ApiModelProperty(name = "flow_context", value = "The context of the flow for which "
            + "the container is created")
    @JsonProperty(value = "flow_context")
    @NotNull(message = "{container.flowContext.notnull}")
    private String flowContext;

    @ApiModelProperty(name = "container_label_type", value = "The container_label_type is type of label.")
    @JsonProperty(value = "container_label_type")
    @NotNull(message = "{container.containerLabelType.notnull}")
    private String containerLabelType;

    @ApiModelProperty(name = "container_label", value = "The container_label is label of container.")
    @JsonProperty(value = "container_label")
    @NotNull(message = "{container.containerLabel.notnull}")
    private String containerLabel;

    @ApiModelProperty(name = "container_type", value = "The container_type is type of container.")
    @JsonProperty(value = "container_type")
    @NotNull(message = "{container.containerType.notnull}")
    private String containerType;

    @ApiModelProperty(name = "state_machine_id", value = "The identifier of the flow for which "
            + "the container is created")
    @JsonProperty(value = "state_machine_id")
    @NotNull(message = "{container.stateMachineId.notnull}")
    private String stateMachineId;

    //currently having max 20 will change according to use case
    @ApiModelProperty(name = "unitizables", value = "The unitizables are the items which needs to be moved "
            + "in container.")
    @JsonProperty(value = "unitizables")
    @NotEmpty(message = "{container.unitizables.notempty}")
    @Valid
    @Size(max = MAX_UNITIZABLES_TO_BE_ADDED, message = "{container.unitizables.size}")
    private List<Unitizable> unitizables;

    @ApiModelProperty(name = "requested_by", value = "The requested_by is the user who requested this operation.")
    @JsonProperty(value = "requested_by")
    @NotNull(message = "{container.requestedBy.notnull}")
    private String requestedBy;

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public String getCreatedByEntityType() {
        return createdByEntityType;
    }

    public void setCreatedByEntityType(String createdByEntityType) {
        this.createdByEntityType = createdByEntityType;
    }

    public String getCreatedByEntityId() {
        return createdByEntityId;
    }

    public void setCreatedByEntityId(String createdByEntityId) {
        this.createdByEntityId = createdByEntityId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getFlowContext() {
        return flowContext;
    }

    public void setFlowContext(String flowContext) {
        this.flowContext = flowContext;
    }

    public String getContainerLabelType() {
        return containerLabelType;
    }

    public void setContainerLabelType(String containerLabelType) {
        this.containerLabelType = containerLabelType;
    }

    public String getContainerLabel() {
        return containerLabel;
    }

    public void setContainerLabel(String containerLabel) {
        this.containerLabel = containerLabel;
    }

    public String getContainerType() {
        return containerType;
    }

    public void setContainerType(String containerType) {
        this.containerType = containerType;
    }

    public String getStateMachineId() {
        return stateMachineId;
    }

    public void setStateMachineId(String stateMachineId) {
        this.stateMachineId = stateMachineId;
    }

    public List<Unitizable> getUnitizables() {
        return unitizables;
    }

    public void setUnitizables(List<Unitizable> unitizables) {
        this.unitizables = unitizables;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }

    @Override
    public String toString() {
        return "AddRequest{" + "idempotenceKey='" + idempotenceKey + '\''
                + ", createdByEntityType='" + createdByEntityType + '\''
                + ", createdByEntityId='" + createdByEntityId + '\'' + ", facilityId='" + facilityId + '\''
                + ", appId='" + appId + '\'' + ", flowContext='" + flowContext + '\''
                + ", containerLabelType='" + containerLabelType + '\'' + ", containerLabel='" + containerLabel + '\''
                + ", containerType='" + containerType + '\'' + ", stateMachineId='" + stateMachineId + '\''
                + ", unitizables=" + unitizables + ", requestedBy='" + requestedBy + '\'' + '}';
    }
}
