package com.ekart.facp.unitization.service.exceptions;
import static com.ekart.facp.unitization.common.ErrorCode.SPECIFICATION_UPDATE_FAILED;
/**
 * Created by anuj.chaudhary on 21/04/16.
 */
public class SpecificationUpdateFailedException extends BaseException {

    public SpecificationUpdateFailedException(Throwable cause) {
        super("Some Error occurred while updating the Resource", SPECIFICATION_UPDATE_FAILED.name(), cause);
    }
}
