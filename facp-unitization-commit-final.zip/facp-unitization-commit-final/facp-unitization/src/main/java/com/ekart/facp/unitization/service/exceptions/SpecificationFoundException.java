package com.ekart.facp.unitization.service.exceptions;
import static com.ekart.facp.unitization.common.ErrorCode.SPECIFICATION_FOUND;
/**
 * Created by anuj.chaudhary on 18/04/16.
 */
public class SpecificationFoundException extends BaseException {
    private final String specificationId;

    public SpecificationFoundException(String specificationId, Throwable cause) {
        super("Specification with id:" + specificationId + " Exists", SPECIFICATION_FOUND.name(), cause);
        this.specificationId = specificationId;
    }

    public String getSpecificationId() {
        return specificationId;
    }
}
