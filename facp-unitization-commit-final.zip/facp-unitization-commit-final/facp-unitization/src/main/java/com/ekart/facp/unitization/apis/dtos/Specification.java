package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.Map;

/**
 * Created by ajeya.hb on 23/03/16.
 */
@ApiModel
public class Specification {

    @ApiModelProperty
    @NotNull
    @JsonProperty(required = true)
    private String id;

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "tenant", required = true)
    private String tenant;

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "type", required = true)
    private String type;

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "reusable", required = true)
    private boolean reusable;

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "active", required = true)
    private boolean active;

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "created_by", required = true)
    private String createdBy;

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "updated_by", required = true)
    private String updatedBy;

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "attributes", required = true)
    private Map<String, String> attributes;

    @ApiModelProperty
    @NotNull
    private long createdAtEpoch;

    @ApiModelProperty
    @NotNull
    private long updatedAtEpoch;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isReusable() {
        return reusable;
    }

    public void setReusable(boolean reusable) {
        this.reusable = reusable;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    public long getCreatedAtEpoch() {
        return createdAtEpoch;
    }

    public void setCreatedAtEpoch(long createdAtEpoch) {
        this.createdAtEpoch = createdAtEpoch;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    public void setUpdatedAtEpoch(long updatedAtEpoch) {
        this.updatedAtEpoch = updatedAtEpoch;
    }

    @Override
    public String toString() {
        return "Specification{" + "id='" + id + '\'' + ", tenant='" + tenant + '\'' + ", type='" + type + '\''
                + ", reusable=" + reusable + ", active=" + active + ", createdBy='" + createdBy + '\''
                + ", updatedBy='" + updatedBy + '\'' + ", attributes=" + attributes + ", createdAtEpoch="
                + createdAtEpoch + ", updatedAtEpoch=" + updatedAtEpoch + '}';
    }
}
