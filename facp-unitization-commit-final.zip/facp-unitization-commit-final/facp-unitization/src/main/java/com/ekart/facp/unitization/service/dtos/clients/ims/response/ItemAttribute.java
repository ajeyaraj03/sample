package com.ekart.facp.unitization.service.dtos.clients.ims.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;

/**
 * Created by anurag.gupta on 19/07/16.
 */
@Immutable
public final class ItemAttribute {
    private final String name;
    private final Object value;

    @JsonCreator
    public ItemAttribute(@JsonProperty(value = "name") String name, @JsonProperty(value = "value") Object value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public Object getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "ItemAttribute{"
                + "name='" + name + '\''
                + ", value=" + value
                + '}';
    }
}

