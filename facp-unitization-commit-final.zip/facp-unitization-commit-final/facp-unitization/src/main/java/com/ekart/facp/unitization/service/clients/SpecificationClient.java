package com.ekart.facp.unitization.service.clients;

import com.ekart.facp.unitization.service.SpecificationService;
import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.utility.TenantContext;

import static jersey.repackaged.com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by anurag.gupta on 04/07/16.
 */
public class SpecificationClient {

    private final SpecificationService specificationService;

    public SpecificationClient(SpecificationService specificationService) {
        this.specificationService = checkNotNull(specificationService);
    }

    public Specification getSpecification(TenantContext tenant, String type) {
        return specificationService.getByType(tenant, type);
    }
}
