package com.ekart.facp.unitization.dal.mysql;

import org.springframework.stereotype.Repository;

/**
 * Marker interface for configuration that this package should be scanned
 *
 * @author vijay.daniel
 */
@Repository
public interface MarkerRepository {

}
