package com.ekart.facp.unitization.service;


import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.unitization.service.clients.FsmClient;
import com.ekart.facp.unitization.service.clients.ImsClient;
import com.ekart.facp.unitization.service.clients.LabelServiceClient;
import com.ekart.facp.unitization.service.clients.SpecificationClient;
import com.ekart.facp.unitization.service.dtos.*;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemAddRequest;
import com.ekart.facp.unitization.service.dtos.clients.ims.request.ItemToUpdate;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.ItemStatus;
import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.exceptions.AddException;
import com.ekart.facp.unitization.service.exceptions.ContainerNotFoundException;
import com.ekart.facp.unitization.service.exceptions.LabelNotFoundException;
import com.ekart.facp.unitization.service.exceptions.UpdateException;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.ekart.facp.unitization.service.validators.*;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import static com.ekart.facp.unitization.apis.constants.ApiConstants.ADD_TO_CONTAINER;
import static com.ekart.facp.unitization.apis.constants.ApiConstants.ADD_UNITIZABLES;
import static com.ekart.facp.unitization.common.enums.Operands.ADD;
import static com.ekart.facp.unitization.common.enums.Operands.REMOVE;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.*;
import static com.ekart.facp.unitization.service.utility.UnitizationUtility.*;
import static jersey.repackaged.com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by anurag.gupta on 01/06/16.
 */
@Service
@ThreadSafe
@ParametersAreNonnullByDefault
public abstract class UnitizationService {

    private final ImsClient imsClient;
    private final FsmClient fsmClient;
    private final SpecificationAttributesValidator specificationAttributesValidator;
    private final UnitizationValidator unitizationValidator;
    private final LabelServiceClient labelServiceClient;

    private static final Logger LOGGER = LoggerFactory.getLogger(UnitizationService.class);

    public UnitizationService(ImsClient imsClient, FsmClient fsmClient,
                              SpecificationAttributesValidator specificationAttributesValidator,
                              UnitizationValidator unitizationValidator, LabelServiceClient labelServiceClient) {
        this.imsClient = checkNotNull(imsClient);
        this.fsmClient = checkNotNull(fsmClient);
        this.specificationAttributesValidator = checkNotNull(specificationAttributesValidator);
        this.unitizationValidator = checkNotNull(unitizationValidator);
        this.labelServiceClient = checkNotNull(labelServiceClient);
    }

    protected ImsClient getImsClient() {
        return imsClient;
    }

    protected FsmClient getFsmClient() {
        return fsmClient;
    }

    protected LabelServiceClient getLabelServiceClient() {
        return labelServiceClient;
    }

    @Timed
    @ExceptionMetered
    public abstract String createContainer(TenantContext tenantContext, Container container);

    @Timed
    @ExceptionMetered
    public void addUnitizablesToContainer(Map<String, String> specificationAttributes, AddRequest moveRequest) {

        //2. fetch Container
        Item container = fetchContainerFromIms(moveRequest.getFacilityId(),
                moveRequest.getContainerLabelType(), moveRequest.getContainerLabel());

        //1. fetch unitizables
        List<Item> items = validateUnitizablesAndFetchItemsFromIms(moveRequest);

        //3. validate and get container validation attributes
        unitizationValidator.validateContainerAttributes(specificationAttributes, items, container);

        Map<String, AggregationResult> aggregationResult = Maps.newHashMap();

        //5. validate rules
        if (isWeightPresentInAllUnitizables(items)) {
            aggregationResult.put(UNITIZATION_CURRENT_WEIGHT.name(),
                    specificationAttributesValidator.getWeightAggregator()
                            .aggregate(container, items, ADD, specificationAttributes));
        }
        aggregationResult.put(UNITIZATION_CURRENT_NO_OF_ITEMS.name(),
                specificationAttributesValidator.getItemsAggregator()
                        .aggregate(container, items, ADD, specificationAttributes));

        //6. validate fsm
        Map<String, ItemStatus> modifiedStatuses = validateAndGetStatusFromFsmForItemsAndContainer(items,
                container, moveRequest);

        //7. get source container
        Item sourceContainer = fetchSourceContainerFromIms(items, moveRequest.getFacilityId());

        //8. add items
        addItems(moveRequest, items, container, sourceContainer, aggregationResult, specificationAttributes,
                modifiedStatuses);
    }

    @Timed
    @ExceptionMetered
    public void updateItem(SpecificationClient specificationClient,
                           String tenant, UpdateRequest updateRequest) {

        //bulk update is not allowed, already handled in DTO UpdateRequest
        UpdateRequestItem updateRequestItem = updateRequest.getUpdateRequestItems().get(0);

        //1. fetch and validate container from IMS
        Item item = fetchItemsFromIms(updateRequest.getFacilityId(), ImmutableMap.of(updateRequestItem.getLabelType(),
                Lists.newArrayList(updateRequestItem.getLabel()))).get(0);

        String processOwner = getOwner(updateRequest.getFlowContext(), updateRequest.getAppId(),
                updateRequestItem.getType());

        //2. create labels in label service and validate
        if( updateRequestItem.getLabelsToBeAdded() != null && !updateRequestItem.getLabelsToBeAdded().isEmpty()) {
            labelServiceClient.createLabelMapping(tenant, updateRequest.getFacilityId(), updateRequestItem.getType(),
                    updateRequest.getRequestedBy(), updateRequest.getIdempotenceKey(),
                    updateRequestItem.getLabelsToBeAdded());
        }
        //3. get next state from FSM
        String nextState = fsmClient.getNextState(item.getStatuses().get(processOwner).getValue(),
                updateRequestItem.getTransitionName(), updateRequestItem.getStateMachineId());

        /**
         * if item is in non-transient container and is addUnitizable allowed with next state
         * that means state of container is being changed to open and because item is in some non-transient
         * container we have to throw error
         */

        List<ItemToUpdate> itemsToUpdate = Lists.newArrayList();

        //4. update parentContainer if weight of container is getting updated and parentContainer is not facility
        if (!item.getContainerId().equals(updateRequest.getFacilityId()) && !(updateRequestItem.getAttributes() == null)
                && updateRequestItem.getAttributes().stream().map(elt -> elt.getName()).collect(Collectors.toList())
                .contains(WEIGHT.name())) {

            Item parentContainer = fetchAndValidateContainerByIdFromIms(updateRequest.getFacilityId(),
                    Lists.newArrayList(item.getContainerId()));
            Specification specification = specificationClient.getSpecification(new TenantContext(tenant),
                    parentContainer.getType());
            if (!getIsTransientFlag(parentContainer) && !specification.getAttributes().isEmpty()
                    && specification.getAttributes().containsKey(MAX_WEIGHT.name())) {
                itemsToUpdate.add(prepareParentContainerToGetUpdated(item, parentContainer, updateRequest,
                        specification));
            }
        }

        //5. prepare update request with attributes, statuses and labels
        itemsToUpdate.add(prepareItemToBeUpdated(item, updateRequestItem, processOwner, nextState));

        //6. call IMS to update items
        imsClient.updateItem(updateRequest, itemsToUpdate);
    }

    private List<Item> validateUnitizablesAndFetchItemsFromIms(AddRequest moveRequest) {

        /**
         * Assuming all the unitizables are of same label type
         * If they are not of same type currently throwing error
         * will change when IMS will provide bulk API for multiple label and labelValues
         */
        unitizationValidator.validateUnitizables(moveRequest.getUnitizables());
        String labelType = moveRequest.getUnitizables().get(0).getLabelType();
        List<String> labelValues = moveRequest.getUnitizables().stream().map(
                elt -> elt.getLabel()).collect(Collectors.toList());
        //get items
        List<Item> items = fetchItemsFromIms(moveRequest.getFacilityId(), ImmutableMap.of(labelType, labelValues));

        unitizationValidator.validateUnitizableLabelsAndState(items, labelType, labelValues,
                moveRequest.getFlowContext(), moveRequest.getAppId());
        return items;
    }

    private List<Item> fetchItemsFromIms(String facilityId, Map<String, List<String>> labelTypeAndValuesMap) {

        //currently support for only one label
        Map.Entry<String, List<String>> firstLabelTypeAndValues = labelTypeAndValuesMap.entrySet().iterator().next();
        List<Item> items = imsClient.getItemsByLabelTypeAndLabelValues(facilityId, firstLabelTypeAndValues.getKey(),
                firstLabelTypeAndValues.getValue());

        if (items.isEmpty()) {
            throw new LabelNotFoundException(firstLabelTypeAndValues.getValue().get(0),
                    firstLabelTypeAndValues.getKey());
        }
        return items;
    }

    private Item fetchContainerFromIms(String facilityId, String labelType, String label) {

        List<Item> containers = imsClient.getItemsByLabelTypeAndLabelValues(facilityId, labelType,
                Lists.newArrayList(label));

        if (containers.isEmpty()) {
            throw new ContainerNotFoundException(label, labelType);
        }
        return containers.get(0);
    }

    private Item fetchSourceContainerFromIms(List<Item> items, String facilityId) {

        //removing from container so need to update source container
        List<String> sourceContainerIds = items.stream().map(elt -> elt.getContainerId()).distinct()
                .collect(Collectors.toList());

        if (sourceContainerIds.size() > 1) {
            throw new AddException("Can not remove items from multiple containers", sourceContainerIds);
        }
        return fetchAndValidateContainerByIdFromIms(facilityId, sourceContainerIds);
    }

    private Item fetchAndValidateContainerByIdFromIms(String facilityId, List<String> containerIds) {

        List<Item> sourceContainers = imsClient.getItemsByIds(facilityId, containerIds);
        if (sourceContainers.isEmpty()) {
            throw new ContainerNotFoundException(containerIds.get(0));
        }
        return sourceContainers.get(0);
    }

    private Map<String, ItemStatus> validateAndGetStatusFromFsmForItemsAndContainer(List<Item> items, Item container,
                                                                    AddRequest addRequest) {
        /**
         * If state for move transition will not be present for items or containers
         * then these methods will throw error
         */
        //taking first need to change when FSM bulk API will be there
        String unitizableProcessOwner = getOwner(addRequest.getFlowContext(),
                addRequest.getAppId(), items.get(0).getType());

        String containerProcessOwner = getOwner(addRequest.getFlowContext(), addRequest.getAppId(),
                container.getType());

        String unitizableState = items.get(0).getStatuses().get(unitizableProcessOwner).getValue();

        String unitizableNextState = fsmClient.getNextState(unitizableState, ADD_TO_CONTAINER,
                addRequest.getUnitizables().get(0).getStateMachineId());

        String containerNextState = fsmClient.getNextState(container.getStatuses().get(
                containerProcessOwner).getValue(), ADD_UNITIZABLES, addRequest.getStateMachineId());

        //updating items and container with new statuses
        Map<String, ItemStatus> modifiedStatuses = Maps.newHashMapWithExpectedSize(items.size() + 1);
        items.stream().forEach(elt -> modifiedStatuses.put(elt.getId(),
                new ItemStatus(unitizableProcessOwner, unitizableNextState)));
        modifiedStatuses.put(container.getId(), new ItemStatus(unitizableProcessOwner, containerNextState));
        return modifiedStatuses;
    }

    private ItemAddRequest prepareSourceContainerToGetUpdated(Item sourceContainer, List<Item> unitizables,
                                                          Map<String, String> specificationAttributes,
                                                          Map<String, ItemStatus> modifiedStatuses) {

        BigDecimal currentWeightInSourceContainer = null;
        if (isWeightPresentInAllUnitizables(unitizables)
                && sourceContainer.getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name())) {
            currentWeightInSourceContainer = specificationAttributesValidator.getWeightAggregator()
                    .aggregate(sourceContainer, unitizables, REMOVE, specificationAttributes).getAggregatedWeight();
        }

        boolean isTransient = getIsTransientFlag(sourceContainer);
        SpecificationAttributesToUpdate attributesToUpdate = new SpecificationAttributesToUpdate();
        attributesToUpdate.setNoOfItems(specificationAttributesValidator.getItemsAggregator()
                .aggregate(sourceContainer, unitizables, REMOVE, specificationAttributes).getNoOfItemsToUpdate());

        if (currentWeightInSourceContainer != null && !isTransient && (attributesToUpdate.getNoOfItems() > 0)) {

            attributesToUpdate.setWeightAttributeToUpdate(currentWeightInSourceContainer);
        }

        if (currentWeightInSourceContainer != null && !isTransient && (attributesToUpdate.getNoOfItems() == 0)) {

            attributesToUpdate.setWeightAttributeToDelete(new BigDecimal(sourceContainer.getAttributes()
                    .get(UNITIZATION_CURRENT_WEIGHT.name()).getValue().toString()));
        }
        return prepareContainerToGetUpdated(sourceContainer, attributesToUpdate, modifiedStatuses);
    }

    private ItemAddRequest prepareDestinationContainerToGetUpdated(Item container, List<Item> unitizables,
                                                                        String containerStateMachineId,
                                                                        Map<String, String> specificationAttributes,
                                                                        Map<String, ItemStatus> modifiedStatuses,
                                                                        Map<String, AggregationResult>
                                                                                aggregationResult) {

        //adding to container so need to update destination container
        SpecificationAttributesToUpdate attributesToUpdate = new SpecificationAttributesToUpdate();
        attributesToUpdate.setNoOfItems(((NumberOfItemsAggregationResult)aggregationResult
                .get(UNITIZATION_CURRENT_NO_OF_ITEMS.name())).getNoOfItemsToUpdate());

        if (specificationAttributes.containsKey(MAX_WEIGHT.name())
                && isWeightPresentInAllUnitizables(unitizables) && !getIsTransientFlag(container)) {

            attributesToUpdate.setWeightAttributeToUpdate(((WeightAggregationResult)aggregationResult
                    .get(UNITIZATION_CURRENT_WEIGHT.name())).getAggregatedWeight());
        }

        if (container.getAttributes().containsKey(UNITIZATION_STATE_MACHINE_ID.name())) {

            String stateMachineId = container.getAttributes()
                    .get(UNITIZATION_STATE_MACHINE_ID.name()).getValue().toString();
            if (!stateMachineId.equals(containerStateMachineId)) {
                throw new AddException("State machine id of container mismatched provided : "
                        + containerStateMachineId + ", stored: " + stateMachineId);
            }
            return prepareContainerToGetUpdated(container, attributesToUpdate, modifiedStatuses);
        }
        return prepareContainerToGetUpdated(container, attributesToUpdate, modifiedStatuses,
                containerStateMachineId);
    }

    private void addItems(AddRequest moveRequest, List<Item> items, Item container, Item sourceContainer,
                          Map<String, AggregationResult> aggregatedResult, Map<String, String> specificationAttributes,
                            Map<String, ItemStatus> modifiedStatuses) {

        List<ItemAddRequest> itemsToMove = Lists.newArrayListWithExpectedSize(items.size() + 2);

        //9. add unitizables
        itemsToMove.addAll(prepareItemsToMove(items, container, getIsTransientFlag(container), modifiedStatuses));

        //10. add source container if source container is not rootContainer
        if (!sourceContainer.getId().equals(moveRequest.getFacilityId())) {
            itemsToMove.add(prepareSourceContainerToGetUpdated(sourceContainer, items, specificationAttributes,
                    modifiedStatuses));
        }
        //11. add destination container if destination container is not rootContainer
        if (!container.getId().equals(moveRequest.getFacilityId())) {
            itemsToMove.add(prepareDestinationContainerToGetUpdated(container, items, moveRequest.getStateMachineId(),
                    specificationAttributes, modifiedStatuses, aggregatedResult));
        }

        //12. call IMS to move Items
        imsClient.moveItems(moveRequest, itemsToMove);
    }

    private ItemToUpdate prepareParentContainerToGetUpdated(Item item, Item parentContainer,
                                                            UpdateRequest updateRequest, Specification specification) {

        if (!parentContainer.getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name())) {
            throw new UpdateException("Can not update weight, items in container do not have weight");
        }
        String parentContainerOwner = getOwner(updateRequest.getFlowContext(), updateRequest.getAppId(),
                parentContainer.getType());
        //validate if parent container is open
        String parentContainerStateMachineId = parentContainer.getAttributes()
                .get(UNITIZATION_STATE_MACHINE_ID.name()).getValue().toString();
        fsmClient.getNextState(parentContainer.getStatuses().get(parentContainerOwner).getValue(), ADD_UNITIZABLES,
                parentContainerStateMachineId);

        return validateRulesForParentContainerAndPrepareForUpdate(parentContainer, item, updateRequest, specification);
    }

    private ItemToUpdate validateRulesForParentContainerAndPrepareForUpdate(Item parentContainer, Item container,
                                                                              UpdateRequest updateRequest,
                                                                              Specification specification) {

        UpdateRequestItem updateRequestItem = updateRequest.getUpdateRequestItems().get(0);
        String weight = updateRequestItem.getAttributes().stream().filter(elt -> elt.getName()
                .equals(WEIGHT.name())).findFirst().get().getValue().toString();

        BigDecimal decrementedCurrentWeightOfParentContainer = specificationAttributesValidator.getWeightAggregator()
                .aggregate(parentContainer, Lists.newArrayList(container), REMOVE, specification.getAttributes())
                .getAggregatedWeight();
        parentContainer.getAttributes().put(UNITIZATION_CURRENT_WEIGHT.name(),
                new ItemAttribute(UNITIZATION_CURRENT_WEIGHT.name(), decrementedCurrentWeightOfParentContainer));
        container.getAttributes().put(WEIGHT.name(), new ItemAttribute(WEIGHT.name(), weight));

        BigDecimal updatedCurrentWeightOfParentContainer = specificationAttributesValidator.getWeightAggregator()
                .aggregate(parentContainer, Lists.newArrayList(container), ADD, specification.getAttributes())
                .getAggregatedWeight();

        return imsClient.prepareItemToUpdate(parentContainer, ImmutableMap.of(UNITIZATION_CURRENT_WEIGHT.name(),
                updatedCurrentWeightOfParentContainer), ImmutableMap.of(), ImmutableMap.of());
    }

    private List<ItemAddRequest> prepareItemsToMove(List<Item> items, Item container, boolean isTransient,
                                                Map<String, ItemStatus> modifiedStatuses) {

        if (isTransient) {
            return imsClient.prepareItemsToMove(items, container, ImmutableMap.of(),
                    ImmutableMap.of(UNITIZATION_IN_CONTAINER.name(), "true"), modifiedStatuses);
        }
        return imsClient.prepareItemsToMove(items, container,
                ImmutableMap.of(UNITIZATION_IN_CONTAINER.name(), "true"), ImmutableMap.of(), modifiedStatuses);
    }

    private ItemAddRequest prepareContainerToGetUpdated(Item container, SpecificationAttributesToUpdate attributes,
                                                   Map<String, ItemStatus> modifiedStatuses, String... stateMachineId) {

        Map<String, Object> modifiedAttributes = getContainerAttributesToBeModified(attributes);
        Map<String, Object> deletedAttributes = getContainerAttributesToBeDeleted(attributes);

        if (attributes.getNoOfItems() == 0) {
            deletedAttributes.put(UNITIZATION_STATE_MACHINE_ID.name(),
                    container.getAttributes().get(UNITIZATION_STATE_MACHINE_ID.name()).getValue());
        }

        if (stateMachineId.length > 0) {
            modifiedAttributes.put(UNITIZATION_STATE_MACHINE_ID.name(), stateMachineId[0]);
        }

        return imsClient.prepareContainerToUpdate(container, modifiedAttributes, deletedAttributes, modifiedStatuses);
    }

    private ItemToUpdate prepareItemToBeUpdated(Item item, UpdateRequestItem updateRequestItem, String processOwner,
                                        String nextState) {

        Map<String, String> labelsToBeAdded = Maps.newHashMap();
        if (updateRequestItem.getLabelsToBeAdded() != null) {
            updateRequestItem.getLabelsToBeAdded().stream().forEach(elt ->
                    labelsToBeAdded.put(elt.getType(), elt.getValue()));
        }

        Map<String, Object> attributes = Maps.newHashMap();
        if (updateRequestItem.getAttributes() != null) {
            updateRequestItem.getAttributes().stream().forEach(elt ->
                    attributes.put(elt.getName(), elt.getValue()));
        }

        return imsClient.prepareItemToUpdate(item, attributes, labelsToBeAdded,
                ImmutableMap.of(processOwner, nextState));
    }
}
