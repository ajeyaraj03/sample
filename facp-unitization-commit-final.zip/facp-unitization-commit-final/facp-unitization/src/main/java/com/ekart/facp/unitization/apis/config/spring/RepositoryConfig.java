package com.ekart.facp.unitization.apis.config.spring;

import com.ekart.facp.unitization.dal.SpecificationRepository;
import com.ekart.facp.unitization.dal.mysql.MarkerRepository;
import com.ekart.facp.unitization.dal.mysql.MysqlSpecificationRepository;
import com.ekart.facp.unitization.dal.mysql.custom.InsertSupportedJpaRepositoryImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import javax.inject.Inject;

@Configuration
@EnableJpaRepositories(basePackageClasses = MarkerRepository.class,
        repositoryBaseClass = InsertSupportedJpaRepositoryImpl.class)
@Import({DatabaseConfig.class, EnvironmentConfig.class})
public class RepositoryConfig {


    @Inject
    private EnvironmentConfig environmentConfig;

    @Inject
    private MysqlSpecificationRepository mysqlSpecificationRepository;

    @Bean
    public SpecificationRepository specificationRepository() {
        return environmentConfig.instrumentor().instrument(mysqlSpecificationRepository, SpecificationRepository.class);
    }
}
