package com.ekart.facp.unitization.common.enums;

/**
 * Created by avinash.r on 08/08/16.
 */
public enum Operands {
    ADD,
    REMOVE
}
