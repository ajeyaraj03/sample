package com.ekart.facp.unitization.common;

/**
 * Created by ajeya.hb on 11/08/16.
 */
public final class Constants {

    private Constants() {
        //restrict constructor instantiation
    }

    public static final String CLIENT_NAME = "UNITIZATION";
}
