package com.ekart.facp.unitization.apis.controller;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.unitization.apis.dtos.*;
import com.ekart.facp.unitization.apis.mapper.ApiDtoToServiceEntityMapper;
import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.utility.ContainerFactory;
import com.ekart.facp.unitization.service.clients.SpecificationClient;
import com.ekart.facp.unitization.service.utility.TenantContext;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.eclipse.jetty.http.HttpStatus;
import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.MediaType;

import static com.ekart.facp.unitization.common.enums.ContainerType.DISPENSIBLE;
import static com.ekart.facp.unitization.common.enums.ContainerType.REUSABLE;
import static jersey.repackaged.com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by anurag.gupta on 09/06/16.
 */
@ThreadSafe
@RequestMapping("/api/v1/unitization")
@ParametersAreNonnullByDefault
@Api(protocols = "http", tags = "Unitization Management")
public class UnitizationController extends BaseController {

    private final SpecificationClient specificationClient;
    private final ContainerFactory containerFactory;
    private final ApiDtoToServiceEntityMapper mapper;
    private static final String TENANT_KEY = "X-Tenant-Context";

    private static final Logger LOGGER = LoggerFactory.getLogger(UnitizationController.class);

    public UnitizationController(SpecificationClient specificationClient, ContainerFactory containerFactory,
                                 ApiDtoToServiceEntityMapper mapper) {
        this.mapper = checkNotNull(mapper);
        this.specificationClient = checkNotNull(specificationClient);
        this.containerFactory = checkNotNull(containerFactory);
    }

    @ApiOperation(nickname = "create_container", value = "Creates new Container")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.CREATED_201, message = "The Container created successfully",
                    response = SuccessResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Unable  to create Container, it may already exists (or) "
                            + "Error due business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON,
            consumes = MediaType.APPLICATION_JSON)

    public ResponseEntity<SuccessResponse> createContainer(@RequestHeader(value = TENANT_KEY, required = true) @Valid
                                                               @NotEmpty String tenant, @RequestBody @Valid @NotNull
                                                            ContainerCreateRequest containerCreateRequest) {
        Specification specification = specificationClient.getSpecification(tenantContext(tenant),
                containerCreateRequest.getType());
        containerFactory.getService(specification.isReusable() ? REUSABLE : DISPENSIBLE).
                createContainer(tenantContext(tenant),
                        mapper.unitizationRequestToContainerServiceEntity(containerCreateRequest));
        return created(new SuccessResponse());
    }

    @ApiOperation(nickname = "add_to_container", value = "move unitizables to container")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200, message = "Moved successfully",
                    response = SuccessResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Error due business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(value = "/add", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON,
            consumes = MediaType.APPLICATION_JSON)
    public ResponseEntity<SuccessResponse> addUnitizables(@RequestHeader(value = TENANT_KEY, required = true) @Valid
                                                @NotEmpty String tenant,
                                            @RequestBody @NotNull @Valid AddRequest addRequest) {

        Specification specification = specificationClient.getSpecification(tenantContext(tenant),
                addRequest.getContainerType());
        containerFactory.getService(specification.isReusable() ? REUSABLE : DISPENSIBLE).
                addUnitizablesToContainer(specification.getAttributes(),
                        mapper.apiToServiceUnitizationMoveRequest(addRequest));

        return ok(new SuccessResponse());
    }

    @ApiOperation(nickname = "update", value = "update containers")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200, message = "Updated successfully",
                    response = SuccessResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Error due business validations. ",
                    response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred",
                    response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(method = RequestMethod.PATCH, produces = MediaType.APPLICATION_JSON,
            consumes = MediaType.APPLICATION_JSON)
    public ResponseEntity<SuccessResponse> updateItem(@RequestHeader(value = TENANT_KEY, required = true) @Valid
                                                          @NotEmpty String tenant,
                                                      @RequestBody @NotNull @Valid UpdateRequest updateRequest) {

        Specification specification = specificationClient.getSpecification(tenantContext(tenant),
                updateRequest.getUpdateRequestItems().get(0).getType());

        containerFactory.getService(specification.isReusable() ? REUSABLE : DISPENSIBLE).
                updateItem(specificationClient, tenant,
                        mapper.apiToServiceUnitizationUpdateRequest(updateRequest));

        return ok(new SuccessResponse());
    }

    private static TenantContext tenantContext(String tenantName) {
        TenantContext tenantContext = new TenantContext(tenantName);
        return tenantContext;
    }
}

