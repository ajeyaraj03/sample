package com.ekart.facp.unitization.service.validators;

import com.ekart.facp.unitization.common.enums.Operands;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;

import java.util.List;
import java.util.Map;

/**
 * Created by avinash.r on 04/08/16.
 */
public interface AggregatorsInterface {

    AggregationResult aggregate(Item container, List<Item> unitizables, Operands operand,
                                       Map<String, String> specificationAttributes);
}
