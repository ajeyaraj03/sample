package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

/**
 * Created by ajeya.hb on 28/03/16.
 */
@ApiModel
public class SuccessResponse {

    @ApiModelProperty(name = "success", value = "boolean value indicating success is true/false")
    @JsonProperty(value = "success")
    private boolean success = true;

    @Override
    public String toString() {
        return "SuccessResponse{"
                + "success=" + success
                + '}';
    }
}
