package com.ekart.facp.unitization.dal.utility;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.AttributeConverter;
import javax.persistence.Converter;
import javax.validation.ValidationException;
import java.io.IOException;
import java.util.Map;

/**
 * Created by ajeya.hb on 23/03/16.
 */
@Converter
public class JpaConverterJson implements AttributeConverter<Map<String, String>, String> {
    private static final Logger LOGGER = LoggerFactory.getLogger(JpaConverterJson.class);
    /**
     * @Inject is not working for Json converter hence creating new object mapper instance
     */
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    @Override
    public String convertToDatabaseColumn(Map<String, String> meta) {
        try {
            return OBJECT_MAPPER.writeValueAsString(meta);
        } catch (JsonProcessingException e) {
            LOGGER.error("DB Data Conversion Error: ", e);
            throw new ValidationException("JSON parsing exception for specification map", e);
        }
    }

    @Override
    public Map<String, String> convertToEntityAttribute(String dbData) {
        try {
            return OBJECT_MAPPER.readValue(dbData, new TypeReference<Map<String, String>>() {
            });
        } catch (IOException e) {
            LOGGER.error("DB Data Conversion Error: ", e);
            throw new ValidationException("Unexpected IO Exception while decoding JSON from database:" + dbData, e);
        }
    }
}
