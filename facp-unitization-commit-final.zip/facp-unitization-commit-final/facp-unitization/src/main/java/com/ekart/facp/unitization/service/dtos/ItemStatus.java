package com.ekart.facp.unitization.service.dtos;

/**
 * Created by anurag.gupta on 27/06/16.
 */
public class ItemStatus {

    private String owner;
    private String value;

    public ItemStatus(String owner, String value) {
        this.owner = owner;
        this.value = value;
    }

    // used by mapstruct
    public ItemStatus() {
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "ItemStatus{"
                + "owner='" + owner + '\''
                + ", value='" + value + '\''
                + '}';
    }
}
