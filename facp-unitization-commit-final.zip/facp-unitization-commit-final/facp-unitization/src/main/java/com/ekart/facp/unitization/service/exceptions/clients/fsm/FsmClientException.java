package com.ekart.facp.unitization.service.exceptions.clients.fsm;

import com.ekart.facp.unitization.service.exceptions.clients.ClientException;

import static com.ekart.facp.unitization.common.ErrorCode.FSM_CLIENT_EXCEPTION;

/**
 * Created by anurag.gupta on 07/07/16.
 */
public class FsmClientException extends ClientException {

    private static final long serialVersionUID = -8719315920559315309L;

    public FsmClientException(String message, String errorCode) {
        super(message, errorCode);
    }
    public FsmClientException(String message, Throwable cause) {
    super(message, FSM_CLIENT_EXCEPTION.name(), cause);
    }
}
