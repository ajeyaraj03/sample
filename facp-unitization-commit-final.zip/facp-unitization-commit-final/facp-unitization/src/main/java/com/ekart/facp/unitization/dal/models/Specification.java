package com.ekart.facp.unitization.dal.models;

import com.ekart.facp.unitization.dal.models.common.BaseEntity;
import com.ekart.facp.unitization.dal.utility.JpaConverterJson;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.persistence.*;
import java.util.Map;

/**
 * Created by ajeya.hb on 23/03/16.
 */
@Entity
@Table(name = "specifications")
@ParametersAreNonnullByDefault
public class Specification extends BaseEntity {

    @Id
    @Column(updatable = false, nullable = false)
    private String id;

    @Column(name = "tenant", nullable = false, updatable = false)
    private String tenant;

    @Column(name = "type", nullable = false, updatable = false)
    private String type;

    @Column(name = "reusable", columnDefinition = "TINYINT(1)", nullable = false)
    private boolean reusable;

    @Column(name = "active", columnDefinition = "TINYINT(1)", nullable = false)
    private boolean active;

    @Column(name = "attributes", nullable = false)
    @Convert(converter = JpaConverterJson.class)
    private Map<String, String> attributes;

    @Column(name = "created_by", nullable = false, updatable = false)
    private String createdBy;

    @Column(name = "updated_by", nullable = false)
    private String updatedBy;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTenant() {
        return tenant;
    }

    public void setTenant(String tenant) {
        this.tenant = tenant;
    }

    public boolean isReusable() {
        return reusable;
    }

    public void setReusable(boolean reusable) {
        this.reusable = reusable;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @Override
    public String toString() {
        return "Specification{"
                + "id='" + id + '\''
                + ", tenant='" + tenant + '\''
                + ", type='" + type + '\'' + ", reusable=" + reusable + ", active=" + active
                + ", attributes=" + attributes + ", createdBy='" + createdBy + '\''
                + ", updatedBy='" + updatedBy + '\'' + '}';
    }
}
