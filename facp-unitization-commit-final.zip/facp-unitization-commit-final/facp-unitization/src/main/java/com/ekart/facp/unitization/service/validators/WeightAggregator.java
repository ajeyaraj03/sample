package com.ekart.facp.unitization.service.validators;

import com.ekart.facp.unitization.common.enums.Operands;
import com.ekart.facp.unitization.service.RuleService;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.exceptions.WeightExceededException;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.MAX_WEIGHT;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.UNITIZATION_CURRENT_WEIGHT;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.WEIGHT;
import static com.ekart.facp.unitization.service.utility.UnitizationUtility.getIsTransientFlag;
import static java.math.BigDecimal.ZERO;

/**
 * Created by avinash.r on 04/08/16.
 */
public class WeightAggregator implements AggregatorsInterface {

    private RuleService ruleService;

    public WeightAggregator(RuleService ruleService) {

        this.ruleService = ruleService;
    }

    public WeightAggregationResult aggregate(Item container, List<Item> unitizables, Operands operand,
                                             Map<String, String> specificationAttributes) {

        BigDecimal weightToBeUpdated = ZERO;

        BigDecimal unitizablesWeight = unitizables.stream().map(
                elt -> new BigDecimal(elt.getAttributes().get(WEIGHT.name()).getValue().toString()))
                .reduce(ZERO, BigDecimal::add);

        BigDecimal containerWeight = ZERO;

        if (container.getAttributes().containsKey(UNITIZATION_CURRENT_WEIGHT.name())) {
            containerWeight = new BigDecimal(container.getAttributes()
                    .get(UNITIZATION_CURRENT_WEIGHT.name()).getValue().toString());
        }

        switch (operand) {
            case ADD:
                weightToBeUpdated = containerWeight.add(unitizablesWeight);
                break;
            case REMOVE:
                weightToBeUpdated = containerWeight.subtract(unitizablesWeight);
                break;
            default:
                weightToBeUpdated = ZERO;
        }

        if (specificationAttributes.containsKey(MAX_WEIGHT.name()) && !getIsTransientFlag(container)
                && !ruleService.maxWeightRule(specificationAttributes, weightToBeUpdated)) {
            throw new WeightExceededException(container.getId(),
                    new BigDecimal(specificationAttributes.get(MAX_WEIGHT.name())), weightToBeUpdated);
        }
        return new WeightAggregationResult(weightToBeUpdated);
    }

}
