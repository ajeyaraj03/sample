package com.ekart.facp.unitization.service.exceptions.clients.fsm;

import com.ekart.facp.unitization.service.exceptions.clients.ClientException;
import static com.ekart.facp.unitization.common.ErrorCode.INVALID_TRANSITION_EXCEPTION;

/**
 * Created by avinash.r on 13/07/16.
 */
public class InvalidTransitionException extends ClientException {

    private static final long serialVersionUID = -9080777953284692750L;

    public InvalidTransitionException(String transition) {
        super(transition + " is not a valid transition.", INVALID_TRANSITION_EXCEPTION.name());
    }
}
