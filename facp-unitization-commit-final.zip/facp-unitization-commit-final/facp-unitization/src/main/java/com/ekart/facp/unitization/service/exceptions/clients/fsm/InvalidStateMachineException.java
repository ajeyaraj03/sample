package com.ekart.facp.unitization.service.exceptions.clients.fsm;


import com.ekart.facp.unitization.service.exceptions.clients.ClientException;

import static com.ekart.facp.unitization.common.ErrorCode.INVALID_STATE_MACHINE_EXCEPTION;

/**
 * Created by anurag.gupta on 17/06/16.
 */
public class InvalidStateMachineException extends ClientException {

    private static final long serialVersionUID = -8719315920559315309L;

    public InvalidStateMachineException(String message) {
        super(message, INVALID_STATE_MACHINE_EXCEPTION.name());
    }
}
