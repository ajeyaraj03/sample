package com.ekart.facp.unitization.service.dtos.clients.ims.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;
import java.util.List;

/**
 * Created by anurag.gupta on 28/06/16.
 */
@Immutable
public final class ItemsCreationResponse {

    private final List<ItemCreationResponse> affectedItems;
    private final List<ItemCreationResponse> modifiedContainers;

    @JsonCreator
    public ItemsCreationResponse(@JsonProperty(value = "affectedItems") List<ItemCreationResponse> affectedItems,
                                 @JsonProperty(value = "modifiedContainers")
                                         List<ItemCreationResponse> modifiedContainers) {
        this.affectedItems = affectedItems;
        this.modifiedContainers = modifiedContainers;
    }

    public List<ItemCreationResponse> getAffectedItems() {
        return affectedItems;
    }

    public List<ItemCreationResponse> getModifiedContainers() {
        return modifiedContainers;
    }

    @Override
    public String toString() {
        return "ItemsCreationResponse{" + "affectedItems=" + affectedItems
                + ", modifiedContainers=" + modifiedContainers + '}';
    }
}
