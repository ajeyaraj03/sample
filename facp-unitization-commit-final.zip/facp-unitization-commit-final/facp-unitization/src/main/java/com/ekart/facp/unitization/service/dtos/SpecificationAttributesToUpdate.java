package com.ekart.facp.unitization.service.dtos;

import java.math.BigDecimal;

/**
 * Created by avinash.r on 03/08/16.
 */
public class SpecificationAttributesToUpdate {

    private Long noOfItems;
    private BigDecimal weightAttributeToUpdate;
    private BigDecimal weightAttributeToDelete;

    public Long getNoOfItems() {
        return noOfItems;
    }

    public void setNoOfItems(Long noOfItems) {
        this.noOfItems = noOfItems;
    }

    public BigDecimal getWeightAttributeToUpdate() {
        return weightAttributeToUpdate;
    }

    public void setWeightAttributeToUpdate(BigDecimal weightAttributeToUpdate) {
        this.weightAttributeToUpdate = weightAttributeToUpdate;
    }

    public BigDecimal getWeightAttributeToDelete() {
        return weightAttributeToDelete;
    }

    public void setWeightAttributeToDelete(BigDecimal weightAttributeToDelete) {
        this.weightAttributeToDelete = weightAttributeToDelete;
    }

    @Override
    public String toString() {
        return "SpecificationAttributesToUpdate{" + "noOfItems=" + noOfItems + ", weightAttributeToUpdate="
                + weightAttributeToUpdate + ", weightAttributeToDelete=" + weightAttributeToDelete + '}';
    }
}
