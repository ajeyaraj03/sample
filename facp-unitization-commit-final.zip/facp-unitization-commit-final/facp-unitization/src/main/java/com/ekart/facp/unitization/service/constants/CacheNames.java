package com.ekart.facp.unitization.service.constants;

/**
 * @author vijay.daniel
 */
public final class CacheNames {

    public static final String SPECIFICATION = "specification";
    public static final String OPTIONAL_ABSENT = "#result==null";

    private CacheNames() {

    }
}
