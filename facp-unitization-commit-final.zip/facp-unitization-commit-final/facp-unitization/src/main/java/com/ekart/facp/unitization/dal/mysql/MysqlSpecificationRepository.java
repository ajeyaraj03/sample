package com.ekart.facp.unitization.dal.mysql;

import com.ekart.facp.unitization.dal.SpecificationRepository;
import com.ekart.facp.unitization.dal.models.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by ajeya.hb on 08/03/16.
 */
@Repository
public interface MysqlSpecificationRepository extends JpaRepository<Specification, String>, SpecificationRepository {
}
