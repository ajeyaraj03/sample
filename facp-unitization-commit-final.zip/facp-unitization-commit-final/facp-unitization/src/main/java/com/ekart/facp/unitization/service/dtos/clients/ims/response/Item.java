package com.ekart.facp.unitization.service.dtos.clients.ims.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;
import java.math.BigDecimal;
import java.util.Map;

/**
 * Created by anurag.gupta on 13/06/16.
 */
@Immutable
public final class Item {

    private final String id;
    private final String createdByDocumentType;
    private final String createdByDocumentId;
    private final String type;
    private final String containerId;
    private final String rootContainerId;
    private final BigDecimal quantity;
    private final String uom;
    private final Map<String, Object> locks;
    private final Map<String, ItemAttribute> attributeGroups;
    private final Map<String, ItemAttribute> attributes;
    private final Map<String, ItemStatus> statuses;
    private final Map<String, ItemLabel> labels;
    private final Map<String, ItemAttribute> taxonomies;
    private final long version;
    private final long createdAtEpoch;
    private final long updatedAtEpoch;

    @JsonCreator
    public Item(@JsonProperty(value = "id") String id,
                @JsonProperty(value = "createdByDocumentType") String createdByDocumentType,
                @JsonProperty(value = "createdByDocumentId") String createdByDocumentId,
                @JsonProperty(value = "type") String type,
                @JsonProperty(value = "containerId") String containerId,
                @JsonProperty(value = "rootContainerId") String rootContainerId,
                @JsonProperty(value = "quantity") BigDecimal quantity,
                @JsonProperty(value = "uom") String uom,
                @JsonProperty(value = "locks") Map<String, Object> locks,
                @JsonProperty(value = "attributeGroups") Map<String, ItemAttribute> attributeGroups,
                @JsonProperty(value = "attributes") Map<String, ItemAttribute> attributes,
                @JsonProperty(value = "statuses") Map<String, ItemStatus> statuses,
                @JsonProperty(value = "labels") Map<String, ItemLabel> labels,
                @JsonProperty(value = "taxonomies") Map<String, ItemAttribute> taxonomies,
                @JsonProperty(value = "version") long version,
                @JsonProperty(value = "createdAtEpoch") long createdAtEpoch,
                @JsonProperty(value = "updatedAtEpoch") long updatedAtEpoch) {
        this.id = id;
        this.createdByDocumentType = createdByDocumentType;
        this.createdByDocumentId = createdByDocumentId;
        this.type = type;
        this.containerId = containerId;
        this.rootContainerId = rootContainerId;
        this.quantity = quantity;
        this.uom = uom;
        this.locks = locks;
        this.attributeGroups = attributeGroups;
        this.attributes = attributes;
        this.statuses = statuses;
        this.labels = labels;
        this.taxonomies = taxonomies;
        this.version = version;
        this.createdAtEpoch = createdAtEpoch;
        this.updatedAtEpoch = updatedAtEpoch;
    }

    public String getId() {
        return id;
    }

    public String getCreatedByDocumentType() {
        return createdByDocumentType;
    }

    public String getCreatedByDocumentId() {
        return createdByDocumentId;
    }

    public String getType() {
        return type;
    }

    public String getContainerId() {
        return containerId;
    }

    public String getRootContainerId() {
        return rootContainerId;
    }

    public BigDecimal getQuantity() {
        return quantity;
    }

    public String getUom() {
        return uom;
    }

    public Map<String, Object> getLocks() {
        return locks;
    }

    public Map<String, ItemAttribute> getAttributeGroups() {
        return attributeGroups;
    }

    public Map<String, ItemAttribute> getAttributes() {
        return attributes;
    }

    public Map<String, ItemStatus> getStatuses() {
        return statuses;
    }

    public Map<String, ItemLabel> getLabels() {
        return labels;
    }

    public Map<String, ItemAttribute> getTaxonomies() {
        return taxonomies;
    }

    public long getVersion() {
        return version;
    }

    public long getCreatedAtEpoch() {
        return createdAtEpoch;
    }

    public long getUpdatedAtEpoch() {
        return updatedAtEpoch;
    }

    @Override
    public String toString() {
        return "Item{" + "id='" + id + '\''
                + ", createdByDocumentType='" + createdByDocumentType + '\''
                + ", createdByDocumentId='" + createdByDocumentId + '\''
                + ", type='" + type + '\''
                + ", containerId='" + containerId + '\''
                + ", rootContainerId='" + rootContainerId + '\''
                + ", quantity=" + quantity
                + ", uom='" + uom + '\''
                + ", locks=" + locks
                + ", attributeGroups=" + attributeGroups
                + ", attributes=" + attributes + ", statuses=" + statuses
                + ", labels=" + labels
                + ", taxonomies=" + taxonomies
                + ", version=" + version
                + ", createdAtEpoch=" + createdAtEpoch
                + ", updatedAtEpoch=" + updatedAtEpoch
                + '}';
    }
}
