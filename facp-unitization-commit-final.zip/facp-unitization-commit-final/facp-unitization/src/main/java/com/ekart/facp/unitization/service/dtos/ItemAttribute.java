package com.ekart.facp.unitization.service.dtos;

/**
 * Created by anurag.gupta on 21/06/16.
 */
public class ItemAttribute {
    private String name;
    private Object value;

    public ItemAttribute(String name, Object value) {
        this.name = name;
        this.value = value;
    }

    //Required for mapstruct
    public ItemAttribute() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object getValue() {
        return value;
    }

    public void setValue(Object value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "ItemAttribute{"
                + "name='" + name + '\''
                + ", value=" + value
                + '}';
    }
}
