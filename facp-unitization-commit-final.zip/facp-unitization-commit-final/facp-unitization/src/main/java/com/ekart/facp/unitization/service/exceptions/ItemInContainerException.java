package com.ekart.facp.unitization.service.exceptions;

import static com.ekart.facp.unitization.common.ErrorCode.ITEM_IN_CONTAINER_EXCEPTION;

/**
 * Created by avinash.r on 13/07/16.
 */
public class ItemInContainerException extends BaseException {
    private static final long serialVersionUID = -6231219009821122278L;

    public ItemInContainerException(String id, String containerID) {
        super("Item " + id + " is already in " + containerID, ITEM_IN_CONTAINER_EXCEPTION.name());
    }
}
