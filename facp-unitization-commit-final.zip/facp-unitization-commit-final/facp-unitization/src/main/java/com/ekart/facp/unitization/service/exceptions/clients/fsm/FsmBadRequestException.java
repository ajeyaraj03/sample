package com.ekart.facp.unitization.service.exceptions.clients.fsm;

import com.ekart.facp.unitization.service.exceptions.clients.ClientException;

/**
 * Created by anurag.gupta on 01/07/16.
 */
public class FsmBadRequestException extends ClientException {

    private static final long serialVersionUID = -8719315920559315309L;

    public FsmBadRequestException(String message, String errorCode) {
        super(message, errorCode);
    }
}
