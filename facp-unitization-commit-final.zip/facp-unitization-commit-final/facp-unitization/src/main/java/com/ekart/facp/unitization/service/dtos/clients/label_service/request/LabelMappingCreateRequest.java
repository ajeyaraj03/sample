package com.ekart.facp.unitization.service.dtos.clients.label_service.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

/**
 * Created by anurag.gupta on 14/07/16.
 */
public class LabelMappingCreateRequest {

    @JsonProperty(value = "created_by")
    private String createdBy;

    @JsonProperty(value = "labels")
    private List<LabelMapping> labels;

    public LabelMappingCreateRequest(String createdBy, List<LabelMapping> labels) {
        this.createdBy = createdBy;
        this.labels = labels;
    }

    public List<LabelMapping> getLabels() {
        return labels;
    }

    public void setLabels(List<LabelMapping> labels) {
        this.labels = labels;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @Override
    public String toString() {
        return "LabelMappingCreateRequest{"
                + "labels=" + labels
                + ", createdBy='" + createdBy + '\''
                + '}';
    }
}
