package com.ekart.facp.unitization.service.exceptions;

import java.math.BigDecimal;

import static com.ekart.facp.unitization.common.ErrorCode.WEIGHT_EXCEEDED_EXCEPTION;

/**
 * Created by avinash.r on 13/07/16.
 */
public class WeightExceededException extends BaseException {

    private static final long serialVersionUID = 5065502394442614255L;

    public WeightExceededException(String id, BigDecimal maxWeight, BigDecimal totalWeight) {
        super("Maximum allowed weight for item " + id + " is " + maxWeight + " but total provided weight is "
                + totalWeight, WEIGHT_EXCEEDED_EXCEPTION.name());
    }
}
