package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.Map;

/**
 * Created by ajeya.hb on 21/06/16.
 */
public class SpecificationUpdateRequest {

    @ApiModelProperty(name = "reusable", value = "Indicates whether the entity type is resuable")
    @JsonProperty(value = "reusable")
    private Boolean reusable;

    @ApiModelProperty(name = "active", value = "Indicates whether the entity type is active or inactive")
    @JsonProperty(value = "active")
    private Boolean active;

    @ApiModelProperty(name = "updated_by", value = "User who is updating the Specification")
    @JsonProperty(value = "updated_by")
    @NotNull(message = "{spec.updatedby.notnull}")
    private String updatedBy;


    @ApiModelProperty(name = "attributes", value = "Attributes which are getting modified")
    @JsonProperty(value = "attributes")
    private Map<String, String> attributes;

    public Boolean getReusable() {
        return reusable;
    }

    public void setReusable(Boolean reusable) {
        this.reusable = reusable;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Map<String, String> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, String> attributes) {
        this.attributes = attributes;
    }

    @Override
    public String toString() {
        return "SpecificationUpdationRequest{"
                + "reusable=" + reusable
                + ", active=" + active
                + ", updatedBy='" + updatedBy + '\''
                + ", attributes=" + attributes
                + '}';
    }
}
