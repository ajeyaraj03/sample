package com.ekart.facp.unitization.service.exceptions;

import static com.ekart.facp.unitization.common.ErrorCode.ADD_EXCEPTION;

/**
 * Created by avinash.r on 13/07/16.
 */
public class AddException extends BaseException {

    private static final long serialVersionUID = -5518407572509393242L;

    public AddException(String message) {
        super(message, ADD_EXCEPTION.name());
    }

    public AddException(String message, Object response) {
        super(message, ADD_EXCEPTION.name(), response);
    }
}
