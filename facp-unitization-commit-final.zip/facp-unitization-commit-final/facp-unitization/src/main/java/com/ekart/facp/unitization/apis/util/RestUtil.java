package com.ekart.facp.unitization.apis.util;

import org.springframework.http.HttpStatus;
/**
 * Created by anurag.gupta on 01/07/16.
 * *refer:
 * http://springinpractice.com/2013/10/07/handling-json-error-object-responses-with-springs-resttemplate
*/
public final class RestUtil {

    private RestUtil() {
    }

    public static boolean isError(HttpStatus status) {
        HttpStatus.Series series = status.series();
        return (HttpStatus.Series.CLIENT_ERROR.equals(series) || HttpStatus.Series.SERVER_ERROR.equals(series));
    }
}

