package com.ekart.facp.unitization.service;

import com.ekart.facp.unitization.service.clients.FsmClient;
import com.ekart.facp.unitization.service.clients.ImsClient;
import com.ekart.facp.unitization.service.clients.LabelServiceClient;
import com.ekart.facp.unitization.service.dtos.Container;
import com.ekart.facp.unitization.service.dtos.ItemLabel;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.exceptions.ContainerAlreadyExistsException;
import com.ekart.facp.unitization.service.exceptions.clients.label_service.LabelAlreadyExists;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.ekart.facp.unitization.service.validators.SpecificationAttributesValidator;
import com.ekart.facp.unitization.service.validators.UnitizationValidator;
import com.google.common.collect.Lists;

import java.util.List;

import static com.ekart.facp.unitization.service.utility.UnitizationUtility.getOwner;

/**
 * Created by anurag.gupta on 01/06/16.
 */
public class ReusableContainerService extends UnitizationService {

    public ReusableContainerService(ImsClient imsClient, FsmClient fsmClient,
                                    SpecificationAttributesValidator specificationAttributesValidator,
                                    UnitizationValidator unitizationValidator, LabelServiceClient labelServiceClient) {
        super(imsClient, fsmClient, specificationAttributesValidator, unitizationValidator, labelServiceClient);
    }


    public String createContainer(TenantContext tenantContext, Container container) {
        String processOwner = getOwner(container.getFlowContext(), container.getAppId(), container.getType());
        try {
            getLabelServiceClient().createLabelMapping(tenantContext.getTenantName(), container.getFacilityId(),
                    container.getType(), container.getCreatedBy(), container.getIdempotenceKey(),
                    Lists.newArrayList(container.getLabel()));
       } catch (LabelAlreadyExists e) {
           validateContainerAlreadyExists(container.getFacilityId(), container.getLabel(), processOwner);
       }
        return getImsClient().createItem(getFsmClient().getInitialState(container.getStateMachineId()),
                processOwner, container);
    }


    private void validateContainerAlreadyExists(String rootContainerId, ItemLabel label, String processOwner) {
        List<Item> items = getImsClient().getItemsByLabel(rootContainerId, label);
        //TODO: sending the associated items information once Item service is ready.
        if (!getImsClient().getItemsByLabel(rootContainerId, label).isEmpty()) {
            throw new ContainerAlreadyExistsException("Container with label type: " + label.getType()
                    + " and label value :" + label.getValue() + " already exists in status: "
                    + getContainerStatusFromItem(processOwner, items.get(0)));
        }
    }

    private String getContainerStatusFromItem(String processOwner, Item item) {
        return item.getStatuses().get(processOwner).getValue();
    }
}


