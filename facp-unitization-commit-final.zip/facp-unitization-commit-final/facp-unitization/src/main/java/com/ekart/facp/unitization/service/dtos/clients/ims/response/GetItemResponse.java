package com.ekart.facp.unitization.service.dtos.clients.ims.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;
import java.util.List;

/**
 * Created by anurag.gupta on 13/06/16.
 */
@Immutable
public final class GetItemResponse {

    private final List<Item> items;

    public GetItemResponse(@JsonProperty(value = "items") List<Item> items) {
        this.items = items;
    }

    public List<Item> getItems() {
        return items;
    }

    @Override
    public String toString() {
        return "GetItemResponse [items=" + items + "]";
    }
}
