package com.ekart.facp.unitization.service.exceptions.clients.label_service;

import com.ekart.facp.unitization.service.exceptions.clients.ClientException;

import static com.ekart.facp.unitization.common.ErrorCode.LABEL_SERVICE_BAD_REQUEST_EXCEPTION;

/**
 * Created by anurag.gupta on 14/07/16.
 */
public class LabelServiceBadRequestException extends ClientException {

    private static final long serialVersionUID = -8719315920559315309L;

    public LabelServiceBadRequestException(String message) {
        super(message, LABEL_SERVICE_BAD_REQUEST_EXCEPTION.name());
    }

    public LabelServiceBadRequestException(String message, String errorCode) {
        super(message, errorCode);
    }
}

