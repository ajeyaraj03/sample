package com.ekart.facp.unitization.service.dtos.clients.ims.request;


import com.ekart.facp.unitization.service.dtos.ItemAttribute;
import com.ekart.facp.unitization.service.dtos.ItemStatus;

import java.util.List;
import java.util.Map;

/**
 * Created by avinash.r on 13/07/16.
 */
public class ItemAddRequest {

    private String id;
    private long lastReadVersion;
    private String newContainerId;
    private long lastReadNewContainerVersion;
    private Map<String, List<ItemAttribute>> attributes;
    private Map<String, List<ItemStatus>> statuses;

    public ItemAddRequest() {
    }

    public ItemAddRequest(String id, long lastReadVersion, String newContainerId, long lastReadNewContainerVersion,
                          Map<String, List<ItemAttribute>> attributes, Map<String, List<ItemStatus>> statuses) {
        this.id = id;
        this.lastReadVersion = lastReadVersion;
        this.newContainerId = newContainerId;
        this.lastReadNewContainerVersion = lastReadNewContainerVersion;
        this.attributes = attributes;
        this.statuses = statuses;
    }

    public ItemAddRequest(String id, long lastReadVersion, Map<String, List<ItemAttribute>> attributes,
                          Map<String, List<ItemStatus>> statuses) {
        this.id = id;
        this.lastReadVersion = lastReadVersion;
        this.attributes = attributes;
        this.statuses = statuses;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public long getLastReadVersion() {
        return lastReadVersion;
    }

    public void setLastReadVersion(long lastReadVersion) {
        this.lastReadVersion = lastReadVersion;
    }

    public String getNewContainerId() {
        return newContainerId;
    }

    public void setNewContainerId(String newContainerId) {
        this.newContainerId = newContainerId;
    }

    public long getLastReadNewContainerVersion() {
        return lastReadNewContainerVersion;
    }

    public void setLastReadNewContainerVersion(long lastReadNewContainerVersion) {
        this.lastReadNewContainerVersion = lastReadNewContainerVersion;
    }

    public Map<String, List<ItemAttribute>> getAttributes() {
        return attributes;
    }

    public void setAttributes(Map<String, List<ItemAttribute>> attributes) {
        this.attributes = attributes;
    }

    public Map<String, List<ItemStatus>> getStatuses() {
        return statuses;
    }

    public void setStatuses(Map<String, List<ItemStatus>> statuses) {
        this.statuses = statuses;
    }

    @Override
    public String toString() {
        return "ItemToMove{" + "id='" + id + '\''
                + ", lastReadVersion=" + lastReadVersion + ", newContainerId='" + newContainerId + '\''
                + ", lastReadNewContainerVersion=" + lastReadNewContainerVersion
                + ", attributes=" + attributes + ", statuses=" + statuses + '}';
    }
}
