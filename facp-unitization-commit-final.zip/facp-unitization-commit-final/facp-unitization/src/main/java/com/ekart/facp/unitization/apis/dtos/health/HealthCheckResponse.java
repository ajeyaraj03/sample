package com.ekart.facp.unitization.apis.dtos.health;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Map;

/**
 * @author vijay.daniel
 *
 */
@ApiModel(value = "response", description = "The result of a health check operation")
public class HealthCheckResponse {

   @ApiModelProperty(name = "service_status", value = "Overall health of the service")
   @JsonProperty(value = "service_status")
   private HealthStatus serviceStatus;

   @ApiModelProperty(name = "component_statuses", value = "Component-level breakdown of health")
   @JsonProperty(value = "component_statuses")
   private Map<String, HealthStatus> componentStatuses;

   public HealthCheckResponse() {

      // For Json deserialization
   }

   public HealthCheckResponse(HealthStatus serviceStatus, Map<String, HealthStatus> componentStatuses) {

      this.serviceStatus = serviceStatus;
      this.componentStatuses = componentStatuses;
   }

   public HealthStatus getServiceStatus() {

      return serviceStatus;
   }

   public void setServiceStatus(HealthStatus serviceStatus) {

      this.serviceStatus = serviceStatus;
   }

   public Map<String, HealthStatus> getComponentStatuses() {

      return componentStatuses;
   }

   public void setComponentStatuses(Map<String, HealthStatus> componentStatuses) {

      this.componentStatuses = componentStatuses;
   }

   @Override
   public int hashCode() {

      final int prime = 31;
      int result = 1;
      result = prime * result + ((componentStatuses == null) ? 0 : componentStatuses.hashCode());
      result = prime * result + ((serviceStatus == null) ? 0 : serviceStatus.hashCode());
      return result;
   }

   @Override
   public boolean equals(Object obj) {

      if (this == obj) {
          return true;
      }
      if (obj == null) {
          return false;
      }
      if (getClass() != obj.getClass()) {
          return false;
      }
      HealthCheckResponse other = (HealthCheckResponse)obj;
      if (componentStatuses == null) {
         if (other.componentStatuses != null) {
             return false;
         }
      } else if (!componentStatuses.equals(other.componentStatuses)) {
          return false;
      }
      if (serviceStatus != other.serviceStatus) {
          return false;
      }
      return true;
   }

   @Override
   public String toString() {

      return "HealthCheckResponse [serviceStatus=" + serviceStatus + ", componentStatuses=" + componentStatuses + "]";
   }
}
