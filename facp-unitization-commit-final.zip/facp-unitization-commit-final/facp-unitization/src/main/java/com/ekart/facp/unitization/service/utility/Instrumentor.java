package com.ekart.facp.unitization.service.utility;

import com.codahale.metrics.MetricRegistry;
import com.codahale.metrics.Timer.Context;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.*;

/**
 * @author vijay.daniel
 */
public class Instrumentor {

    private final MetricRegistry metricRegistry;

    public Instrumentor(MetricRegistry metricRegistry) {

        this.metricRegistry = metricRegistry;
    }

    public <T> T instrument(T obj, Class<T> clazz) {

        return instrument(obj, clazz, clazz.getCanonicalName());
    }

    @SuppressWarnings("unchecked")
    public <T> T instrument(T obj, Class<T> clazz, String prefixClassName) {

        return (T)Proxy.newProxyInstance(clazz.getClassLoader(), new Class<?>[]{clazz},
                new MetricsInvocationHandler(metricRegistry, obj, prefixClassName, clazz));
    }

    private static class MetricsInvocationHandler implements InvocationHandler {

        private final MetricRegistry metricRegistry;
        private final Object originalObject;
        private final ImmutableMap<String, String> methodMetricNames;

        public MetricsInvocationHandler(MetricRegistry metricRegistry, Object originalObject, String prefixClassName,
                                        Class<?> clazz) {

            this.metricRegistry = metricRegistry;
            this.originalObject = originalObject;
            Builder<String, String> mapBuilder = ImmutableMap.<String, String>builder();

            ReflectionUtils.doWithMethods(clazz, m -> {
                String metricName = prefixClassName + "." + m.getName();
                mapBuilder.put(m.getName(), metricName);
                metricRegistry.timer(metricName);
                metricRegistry.meter(metricName + ".exceptions");
            }, m -> (Modifier.isPublic(m.getModifiers()) && !Modifier.isStatic(m.getModifiers())));

            this.methodMetricNames = mapBuilder.build();
        }

        @Override
        public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {

            String metricName = methodMetricNames.get(method.getName());
            Context timerContext = null;

            if (metricName != null) {

                timerContext = metricRegistry.timer(metricName).time();
            }

            try {

                return method.invoke(originalObject, args);

            } catch (InvocationTargetException t) {

                if (metricName != null) {

                    metricRegistry.meter(metricName + ".exceptions").mark();
                }
                throw t.getCause();

            } finally {

                if (metricName != null) {

                    timerContext.close();
                }
            }
        }
    }
}
