package com.ekart.facp.unitization.service.dtos.clients.label_service.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;
import java.util.Map;

/**
 * Created by anurag.gupta on 14/07/16.
 */
@Immutable
public final class LabelMappingCreateResponse {

    private final String facilityId;
    private final Map<String, String> labels;
    private final String entityType;

    @JsonCreator
    public LabelMappingCreateResponse(@JsonProperty(value = "facility_id") String facilityId,
                                      @JsonProperty(value = "labels") Map<String, String> labels,
                                      @JsonProperty(value = "entity_type")String entityType) {
        this.facilityId = facilityId;
        this.labels = labels;
        this.entityType = entityType;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public Map<String, String> getLabels() {
        return labels;
    }

    public String getEntityType() {
        return entityType;
    }

    @Override
    public String toString() {
        return "LabelMappingCreateResponse{"
                + "facilityId='" + facilityId + '\''
                + ", labels=" + labels
                + ", entityType='" + entityType + '\''
                + '}';
    }
}

