package com.ekart.facp.unitization.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;

/**
 * Created by avinash.r on 13/07/16.
 */
@ApiModel
public class Unitizable {

    @ApiModelProperty(name = "label", value = "The label of the unitizable.")
    @JsonProperty(value = "label")
    @NotNull(message = "{unitizable.label.notnull}")
    private String label;

    @ApiModelProperty(name = "label_type", value = "The label_type of the unitizable.")
    @JsonProperty(value = "label_type")
    @NotNull(message = "{container.labelType.notnull}")
    private String labelType;

    @ApiModelProperty(name = "state_machine_id", value = "The identifier of the flow for which "
            + "the unitizable is created")
    @JsonProperty(value = "state_machine_id")
    @NotNull(message = "{container.stateMachineId.notnull}")
    private String stateMachineId;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getLabelType() {
        return labelType;
    }

    public void setLabelType(String labelType) {
        this.labelType = labelType;
    }

    public String getStateMachineId() {
        return stateMachineId;
    }

    public void setStateMachineId(String stateMachineId) {
        this.stateMachineId = stateMachineId;
    }

    @Override
    public String toString() {
        return "Unitizable{" + "label='" + label + '\'' + ", labelType='" + labelType + '\''
                + ", stateMachineId='" + stateMachineId + '\'' + '}';
    }
}
