package com.ekart.facp.unitization.apis.dtos;

/**
 * Created by ajeya.hb on 21/06/16.
 */
public class SpecificationCreationResponse {

    private String specificationId;

    public SpecificationCreationResponse() {
        // For Json deserialization

    }

    public SpecificationCreationResponse(String specificationId) {
        this.specificationId = specificationId;
    }

    public String getSpecificationId() {
        return specificationId;
    }

    public void setSpecificationId(String specificationId) {
        this.specificationId = specificationId;
    }

    @Override
    public String toString() {
        return "SpecificationCreationResponse{"
                + "specificationId='" + specificationId
                + '\''
                +
                '}';
    }
}
