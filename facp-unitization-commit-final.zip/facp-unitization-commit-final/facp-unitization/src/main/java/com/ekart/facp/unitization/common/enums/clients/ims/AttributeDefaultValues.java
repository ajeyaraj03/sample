package com.ekart.facp.unitization.common.enums.clients.ims;

/**
 * Created by anurag.gupta on 05/07/16.
 */
public enum AttributeDefaultValues {
    CURRENT_WEIGHT(0),
    CURRENT_NO_OF_ITEMS(0),
    QUANITY(1),
    LAST_READ_CONTAINER_VERSION(0);

    private int value;

    AttributeDefaultValues(int defaultValue) {
        this.value = defaultValue;
    }

    public int getValue() {
        return value;
    }
}
