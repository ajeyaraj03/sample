package com.ekart.facp.unitization.common.enums;

import javax.annotation.concurrent.Immutable;

/**
 * Created by anurag.gupta on 01/06/16.
 */
@Immutable
public enum ContainerType {
    REUSABLE,
    DISPENSIBLE
}
