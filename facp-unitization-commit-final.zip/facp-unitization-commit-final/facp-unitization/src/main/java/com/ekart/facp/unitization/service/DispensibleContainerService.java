package com.ekart.facp.unitization.service;

import com.ekart.facp.unitization.service.clients.FsmClient;
import com.ekart.facp.unitization.service.clients.ImsClient;
import com.ekart.facp.unitization.service.clients.LabelServiceClient;
import com.ekart.facp.unitization.service.dtos.Container;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.ekart.facp.unitization.service.validators.SpecificationAttributesValidator;
import com.ekart.facp.unitization.service.validators.UnitizationValidator;
import com.google.common.collect.Lists;

import static com.ekart.facp.unitization.service.utility.UnitizationUtility.getOwner;

/**
 * Created by anurag.gupta on 01/06/16.
 */
public class  DispensibleContainerService extends UnitizationService {


    public DispensibleContainerService(ImsClient imsClient, FsmClient fsmClient,
                                       SpecificationAttributesValidator specificationAttributesValidator,
                                       UnitizationValidator unitizationValidator,
                                       LabelServiceClient labelServiceClient) {
        super(imsClient, fsmClient, specificationAttributesValidator, unitizationValidator, labelServiceClient);
    }

    @Override
    public String createContainer(TenantContext tenantContext, Container container) {

        getLabelServiceClient().createLabelMapping(tenantContext.getTenantName(), container.getFacilityId(),
                container.getType(), container.getCreatedBy(), container.getIdempotenceKey(),
                Lists.newArrayList(container.getLabel()));

        return getImsClient().createItem(getFsmClient().getInitialState(container.getStateMachineId()), getOwner(
                container.getFlowContext(), container.getAppId(), container.getType()), container);
    }
}
