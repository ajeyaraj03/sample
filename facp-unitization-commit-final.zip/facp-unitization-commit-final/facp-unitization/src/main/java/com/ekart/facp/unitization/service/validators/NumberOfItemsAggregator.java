package com.ekart.facp.unitization.service.validators;

import com.ekart.facp.unitization.common.enums.Operands;
import com.ekart.facp.unitization.service.RuleService;
import com.ekart.facp.unitization.service.dtos.clients.ims.response.Item;
import com.ekart.facp.unitization.service.exceptions.NumberOfItemsExceededException;

import java.util.List;
import java.util.Map;

import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.MAX_NO_OF_ITEMS;
import static com.ekart.facp.unitization.common.enums.clients.ims.AttributeName.UNITIZATION_CURRENT_NO_OF_ITEMS;
import static com.ekart.facp.unitization.service.utility.UnitizationUtility.getIsTransientFlag;

/**
 * Created by avinash.r on 04/08/16.
 */
public class NumberOfItemsAggregator implements AggregatorsInterface {

    private RuleService ruleService;

    public NumberOfItemsAggregator(RuleService ruleService) {
        this.ruleService = ruleService;
    }

    public NumberOfItemsAggregationResult aggregate(Item container, List<Item> unitizables, Operands operand,
                                                    Map<String, String> specificationAttributes) {

        Long noOfItemsToUpdate = 0L;

        long currentNoOfItemsInContainer = 0L;

        if (container.getAttributes().containsKey(UNITIZATION_CURRENT_NO_OF_ITEMS.name())) {
            currentNoOfItemsInContainer = Long.parseLong(container.getAttributes()
                    .get(UNITIZATION_CURRENT_NO_OF_ITEMS.name()).getValue().toString());
        }

        switch (operand) {
            case ADD:
                noOfItemsToUpdate = currentNoOfItemsInContainer + unitizables.size();
                break;
            case REMOVE:
                noOfItemsToUpdate = currentNoOfItemsInContainer - unitizables.size();
                break;
            default:
                noOfItemsToUpdate = 0L;
        }

        if (specificationAttributes.containsKey(MAX_NO_OF_ITEMS.name()) && !getIsTransientFlag(container)
                && !ruleService.maxNoOfItemsRule(specificationAttributes, noOfItemsToUpdate)) {
            throw new NumberOfItemsExceededException(container.getId(),
                    Long.parseLong(specificationAttributes.get(MAX_NO_OF_ITEMS.name())), noOfItemsToUpdate);
        }
        return new NumberOfItemsAggregationResult(noOfItemsToUpdate);
    }

}
