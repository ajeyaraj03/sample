package com.ekart.facp.unitization.service.exceptions;

import static com.ekart.facp.unitization.common.ErrorCode.UPDATE_EXCEPTION;
/**
 * Created by avinash.r on 19/07/16.
 */
public class UpdateException extends BaseException {

    private static final long serialVersionUID = -2876134749292378712L;

    public UpdateException(String message) {
        super(message, UPDATE_EXCEPTION.name());
    }
}
