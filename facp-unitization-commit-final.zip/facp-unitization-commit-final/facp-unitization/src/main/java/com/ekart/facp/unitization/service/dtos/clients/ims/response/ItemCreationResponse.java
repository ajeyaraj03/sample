package com.ekart.facp.unitization.service.dtos.clients.ims.response;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;

/**
 * Created by anurag.gupta on 28/06/16.
 */
@Immutable
public final class ItemCreationResponse {

    private final String itemId;
    private final int itemVersion;
    private final int oldItemVersion;

    public String getItemId() {
        return itemId;
    }

    @JsonCreator
    public ItemCreationResponse(@JsonProperty(value = "itemId") String itemId,
                                @JsonProperty(value = "itemVersion") int itemVersion,
                                @JsonProperty(value = "oldItemVersion") int oldItemVersion) {
        this.itemId = itemId;
        this.itemVersion = itemVersion;
        this.oldItemVersion = oldItemVersion;
    }

    public int getItemVersion() {
        return itemVersion;
    }
    public int getOldItemVersion() {
        return oldItemVersion;
    }
    @Override
    public String toString() {
        return "ItemCreationResponse{"
                + "itemId='" + itemId + '\''
                + ", itemVersion=" + itemVersion
                + ", oldItemVersion=" + oldItemVersion
                + '}';
    }
}
