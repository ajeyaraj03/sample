package com.ekart.facp.unitization.service.impl;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.unitization.apis.util.UUIDGenerator;
import com.ekart.facp.unitization.dal.SpecificationRepository;
import com.ekart.facp.unitization.service.SpecificationService;
import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.entities.SpecificationCreationRequest;
import com.ekart.facp.unitization.service.entities.SpecificationUpdationRequest;
import com.ekart.facp.unitization.service.exceptions.SpecificationCreationFailedException;
import com.ekart.facp.unitization.service.exceptions.SpecificationFoundException;
import com.ekart.facp.unitization.service.exceptions.SpecificationNotFoundException;
import com.ekart.facp.unitization.service.exceptions.SpecificationUpdateFailedException;
import com.ekart.facp.unitization.service.mapper.ServiceEntityToDALModelMapper;
import com.ekart.facp.unitization.service.utility.TenantContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang.Validate;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.io.IOException;
import java.util.Optional;
import java.util.function.Supplier;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by ajeya.hb on 23/03/16.
 */
@Service
@ThreadSafe
@ParametersAreNonnullByDefault
public class SpecificationServiceImpl implements SpecificationService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SpecificationServiceImpl.class);
    private final SpecificationRepository specificationRepository;
    private final ServiceEntityToDALModelMapper mapper;
    private final ObjectMapper objectMapper;
    private final UUIDGenerator uuidGenerator;
    private final Supplier<DateTime> currentTimeSupplier;

    public SpecificationServiceImpl(SpecificationRepository specificationRepository,
                                    ServiceEntityToDALModelMapper serviceAndDAOMapper, ObjectMapper objectMapper,
                                    UUIDGenerator uuidGenerator, Supplier<DateTime> currentTimeSupplier) {
        this.specificationRepository = checkNotNull(specificationRepository);
        this.mapper = checkNotNull(serviceAndDAOMapper);
        this.objectMapper = checkNotNull(objectMapper);
        this.uuidGenerator = checkNotNull(uuidGenerator);
        this.currentTimeSupplier = checkNotNull(currentTimeSupplier);
    }

    @Override
    @Transactional
    @Timed
    @ExceptionMetered
    public String create(TenantContext tenantContext, SpecificationCreationRequest specificationCreationRequest) {

        long currentTimeInMillis = currentTimeSupplier.get().getMillis();
        com.ekart.facp.unitization.dal.models.Specification specification =
                mapper.specificationCreateEntityToSpecificationModel(uuidGenerator.generate().toString(),
                        tenantContext.getTenantName(), specificationCreationRequest,
                        specificationCreationRequest.getCreatedBy(), currentTimeInMillis, currentTimeInMillis);
        try {
            specificationRepository.insertAndFlush(specification);
        } catch (DataIntegrityViolationException e) {
            /** request is idempotent on tenant,type and active attributes */
            Optional<com.ekart.facp.unitization.dal.models.Specification> specificationResult =
                    Optional.ofNullable(specificationRepository.findByTenantAndType(
                            tenantContext.getTenantName(),
                            specificationCreationRequest.getType()));
            /** Resource Exists exception is handled in controller,
             *  which is required to break transaction when exception is thrown by JPA or else it will try to
             *  rollback the record and rollback exception*/
            if (specificationResult.get().isActive() == specificationCreationRequest.isActive()) {
                throw new SpecificationFoundException(specificationResult.get().getId(), e);
            } else {
                throw new SpecificationCreationFailedException("Specification", tenantContext.getTenantName(),
                        specificationCreationRequest.getType(), specificationResult.get().isActive(), e);
            }
        }
        return specification.getId();
    }

    @Override
    @Transactional
    @Timed
    @ExceptionMetered
    public void update(TenantContext tenantContext, SpecificationUpdationRequest specificationUpdationRequest) {

        com.ekart.facp.unitization.dal.models.Specification specificationModel = specificationRepository.
                findById(specificationUpdationRequest.getId()).orElseThrow(() ->
                new SpecificationNotFoundException("Specification with id : " + specificationUpdationRequest.getId()
                        + " not found"));
        try {
            specificationModel = objectMapper.readerForUpdating(specificationModel).
                    readValue(objectMapper.writeValueAsString(specificationUpdationRequest));
            specificationModel.setUpdatedAtEpoch(currentTimeSupplier.get().getMillis());
        } catch (IOException ioE) {
            LOGGER.error("Exception Stack trace: ", ioE);
            throw new SpecificationUpdateFailedException(ioE);
        }
        specificationRepository.saveAndFlush(specificationModel);
    }

    @Override
    @Transactional
    @Timed
    @ExceptionMetered
    public void remove(TenantContext tenantContext, String specificationId) {
        com.ekart.facp.unitization.dal.models.Specification specification = specificationRepository.
                findById(specificationId).orElseThrow(() ->
                new SpecificationNotFoundException("Specification with id : " + specificationId + " not found"));
        specification.setArchived(true);
        specificationRepository.saveAndFlush(specification);
    }

    @Override
    @Timed
    @ExceptionMetered
    public Specification get(TenantContext tenantContext, String specificationId) {
        /** These validations are added because in unitization we are using service injection */
        Validate.notEmpty(specificationId, "specification id is mandatory");
        return specificationRepository.findById(specificationId)
                .map(mapper::specificationModelToSpecification).orElseThrow(() ->
                        new SpecificationNotFoundException("Specification with id : "
                                + specificationId + " not found"));
    }

    @Override
    @Timed
    @ExceptionMetered
    public Specification getByType(TenantContext tenantContext, String type) {
        /** These validations are added because in unitization we are using service injection */
        Validate.notEmpty(tenantContext.getTenantName(), "Tenant Name is mandatory");
        Validate.notEmpty(type, "Type is mandatory");

        return Optional.ofNullable(specificationRepository.findByTenantAndType(
                tenantContext.getTenantName(), type))
                .filter(spec -> spec.isActive())
                .map(mapper::specificationModelToSpecification).orElseThrow(() ->
                new SpecificationNotFoundException("The Specification identified by tenant: "
                        + tenantContext.getTenantName()
                        + "  and type "
                        + type + " was not found"));
    }

    @Override
    @Timed
    @ExceptionMetered
    public Specification getInactiveByType(TenantContext tenantContext, String type) {
        /** These validations are added because in unitization we are using service injection */
        Validate.notEmpty(tenantContext.getTenantName(), "Tenant Name is mandatory");
        Validate.notEmpty(type, "Type is mandatory");
        return Optional.ofNullable(specificationRepository.findByTenantAndType(tenantContext.getTenantName(), type))
                .filter(spec -> !spec.isActive())
                .map(mapper::specificationModelToSpecification).orElseThrow(() ->
                        new SpecificationNotFoundException("The Specification "
                                + "identified by tenant: " + tenantContext.getTenantName() + "  and type "
                                + type + " was not found"));

    }

}
