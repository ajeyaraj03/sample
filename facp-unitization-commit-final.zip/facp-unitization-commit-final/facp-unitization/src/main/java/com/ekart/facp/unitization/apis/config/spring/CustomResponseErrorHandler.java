package com.ekart.facp.unitization.apis.config.spring;

import com.ekart.facp.unitization.apis.util.RestUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.web.client.ResponseErrorHandler;

import java.io.IOException;

/**
 * Created by anurag.gupta on 01/07/16.
 * refer:
 * http://springinpractice.com/2013/10/07/handling-json-error-object-responses-with-springs-resttemplate
 */

public class CustomResponseErrorHandler implements ResponseErrorHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(CustomResponseErrorHandler.class);

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {
        return RestUtil.isError(response.getStatusCode());
    }

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {
        LOGGER.error("Response error: {} {}", response.getStatusCode(), response.getStatusText());
    }
}
