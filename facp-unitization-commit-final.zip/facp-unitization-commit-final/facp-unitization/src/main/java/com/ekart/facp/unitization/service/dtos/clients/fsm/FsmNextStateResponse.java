package com.ekart.facp.unitization.service.dtos.clients.fsm;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import jdk.nashorn.internal.ir.annotations.Immutable;

/**
 * Created by avinash.r on 13/07/16.
 */
@Immutable
public final class FsmNextStateResponse {

    private final String stateName;
    private final long version;

    @JsonCreator
    public FsmNextStateResponse(@JsonProperty("state_name") String stateName,
                                @JsonProperty("version") long version) {
        this.stateName = stateName;
        this.version = version;
    }

    public String getNextState() {
        return stateName;
    }

    public long getVersion() {
        return version;
    }

    @Override
    public String toString() {
        return "FsmNextStateResponse{" + "stateName='" + stateName + '\'' + ", version=" + version + '}';
    }
}
