package com.ekart.facp.unitization.service.dtos;

import com.ekart.facp.unitization.apis.dtos.*;

import java.util.List;

/**
 * Created by avinash.r on 13/07/16.
 */
public class UpdateRequest {

    private String idempotenceKey;
    private String createdByEntityType;
    private String createdByEntityId;
    private String facilityId;
    private String appId;
    private String flowContext;
    private List<UpdateRequestItem> updateRequestItems;
    private String requestedBy;

    public String getIdempotenceKey() {
        return idempotenceKey;
    }

    public void setIdempotenceKey(String idempotenceKey) {
        this.idempotenceKey = idempotenceKey;
    }

    public String getCreatedByEntityType() {
        return createdByEntityType;
    }

    public void setCreatedByEntityType(String createdByEntityType) {
        this.createdByEntityType = createdByEntityType;
    }

    public String getCreatedByEntityId() {
        return createdByEntityId;
    }

    public void setCreatedByEntityId(String createdByEntityId) {
        this.createdByEntityId = createdByEntityId;
    }

    public String getFacilityId() {
        return facilityId;
    }

    public void setFacilityId(String facilityId) {
        this.facilityId = facilityId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public List<UpdateRequestItem> getUpdateRequestItems() {
        return updateRequestItems;
    }

    public void setUpdateRequestItems(List<UpdateRequestItem> updateRequestItems) {
        this.updateRequestItems = updateRequestItems;
    }

    public String getRequestedBy() {
        return requestedBy;
    }

    public void setRequestedBy(String requestedBy) {
        this.requestedBy = requestedBy;
    }

    public String getFlowContext() {
        return flowContext;
    }

    public void setFlowContext(String flowContext) {
        this.flowContext = flowContext;
    }

    @Override
    public String toString() {
        return "UpdateRequest{" + "idempotenceKey='" + idempotenceKey + '\''
                + ", createdByEntityType='" + createdByEntityType + '\''
                + ", createdByEntityId='" + createdByEntityId + '\'' + ", facilityId='" + facilityId + '\''
                + ", appId='" + appId + '\'' + ", flowContext='" + flowContext + '\''
                + ", updateRequestItems=" + updateRequestItems + ", requestedBy='" + requestedBy + '\'' + '}';
    }
}
