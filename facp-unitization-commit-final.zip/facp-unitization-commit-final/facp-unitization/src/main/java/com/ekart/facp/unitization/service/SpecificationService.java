package com.ekart.facp.unitization.service;

import com.ekart.facp.unitization.service.entities.Specification;
import com.ekart.facp.unitization.service.entities.SpecificationCreationRequest;
import com.ekart.facp.unitization.service.entities.SpecificationUpdationRequest;
import com.ekart.facp.unitization.service.utility.TenantContext;

/**
 * Created by ajeya.hb on 23/03/16.
 */

public interface SpecificationService {

    String create(TenantContext tenantContext, SpecificationCreationRequest specification);

    void update(TenantContext tenantContext, SpecificationUpdationRequest specification);

    void remove(TenantContext tenantContext, String specificationId);

    Specification get(TenantContext tenantContext, String specificationId);

    Specification getByType(TenantContext tenantContext, String type);

    Specification getInactiveByType(TenantContext tenantContext, String type);

}
