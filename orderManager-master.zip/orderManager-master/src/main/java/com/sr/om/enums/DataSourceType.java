package com.sr.om.enums;

public enum DataSourceType {

    WRITE, READ
}
