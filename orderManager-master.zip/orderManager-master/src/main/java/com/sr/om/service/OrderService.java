package com.sr.om.service;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.sr.om.dal.mysql.model.Order;

@Service
public interface OrderService {

	public Map<String, String> createOrder(Order orderEntity);
	public Map<String, String> startProcess(Long orderId, String vendorUid);
	public Map<String, Object> searchOrder(String orderId);
}
