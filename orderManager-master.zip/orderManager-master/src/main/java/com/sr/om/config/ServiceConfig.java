package com.sr.om.config;

import javax.inject.Inject;

import org.activiti.engine.impl.RuntimeServiceImpl;
import org.springframework.context.annotation.Bean;

import com.sr.om.dal.OrderRepository;
import com.sr.om.service.OrderService;
import com.sr.om.service.impl.OrderServiceImpl;

public class ServiceConfig {
	
	@Inject
	private OrderRepository orderRepository;
	
	@Bean
	public OrderService orderService()
	{
	return new OrderServiceImpl(orderRepository, new RuntimeServiceImpl());
	}

}
