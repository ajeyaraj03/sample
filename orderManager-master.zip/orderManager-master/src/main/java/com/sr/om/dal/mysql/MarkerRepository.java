package com.sr.om.dal.mysql;

import org.springframework.stereotype.Repository;

/**
 * Marker interface for configuration that this package should be scanned
 *
 * 
 */
@Repository
public interface MarkerRepository {

}
